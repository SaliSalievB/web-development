<?php
error_reporting(0);
session_start();

// add product to cart
if (isset($_POST['add_to_cart'])) {
    $product_id = $_POST['product_id'];
    $product_name = $_POST['product_name'];
    $product_price = $_POST['product_price'];
    $quantity = $_POST['quantity'];

    // create new item array
    $item_array = array(
        'product_id' => $product_id,
        'product_name' => $product_name,
        'product_price' => $product_price,
        'quantity' => $quantity
    );

    // add item to cart
    if (isset($_SESSION['cart'])) {
        $found = false;

        foreach ($_SESSION['cart'] as $key => $value) {
            if ($value['product_id'] == $product_id) {
                $_SESSION['cart'][$key]['quantity'] += $quantity;
                $found = true;
                break;
            }
        }

        if (!$found) {
            $_SESSION['cart'][] = $item_array;
        }
    } else {
        $_SESSION['cart'][] = $item_array;
    }
}

// update cart
if (isset($_POST['update_cart'])) {
    foreach ($_POST['quantity'] as $key => $value) {
        if ($value == 0) {
            unset($_SESSION['cart'][$key]);
        } else {
            $_SESSION['cart'][$key]['quantity'] = $value;
        }
    }
}

// remove item from cart
if (isset($_GET['remove'])) {
    $product_id = $_GET['remove'];

    foreach ($_SESSION['cart'] as $key => $value) {
        if ($value['product_id'] == $product_id) {
            unset($_SESSION['cart'][$key]);
            break;
        }
    }
}

// clear cart
if (isset($_GET['clear'])) {
    unset($_SESSION['cart']);
}
// display cart
function display_cart()
{
    if (!empty($_SESSION["cart"])) {
        echo "<table>";
        echo "<thead><tr><th>Product</th><th>Price</th><th>Quantity</th><th>Total</th></tr></thead>";
        echo "<tbody>";
        $total = 0;
        foreach ($_SESSION["cart"] as $product_id => $product) {
            $product_name = $product["name"];
            $product_price = $product["price"];
            $product_qty = $product["qty"];
            $product_total = $product_price * $product_qty;
            echo "<tr>";
            echo "<td>{$product_name}</td>";
            echo "<td>{$product_price} лв.</td>";
            echo "<td>{$product_qty}</td>";
            echo "<td>{$product_total} лв.</td>";
            echo "</tr>";
            $total += $product_total;
        }
        echo "<tr><td colspan='3' align='right'>Total:</td><td>{$total} лв.</td></tr>";
        echo "</tbody>";
        echo "</table>";
    } else {
        echo "Your cart is empty.";
    }
}
?>
<!DOCTYPE html>
<html>
   <head>
      <title>RIV Electronics</title>
      <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
   </head>
   <style>
      body{
      margin: 0;
      background-color: rgba(30,10,1,255);
      color: antiquewhite;
      }
      a {
      background-color: rgba(30,10,1,255);
      color: #fff;
      border: none;
      padding: 10px 20px;
      font-size: 16px;
      border-radius: 5px;
      cursor: pointer;
      transition: all 0.3s ease;
      }
      a:hover {
      background-color: #000;
      color: #fff;
      }
      header {
      display: grid;
      grid-template-columns: 1fr auto 1fr;
      grid-template-rows: auto auto;
      grid-template-areas: 
      ". name nav"
      "logo name nav";
      align-items: center;
      justify-items: center;
      padding: -50px;
      background-color: rgba(30,10,1,255);
      box-shadow: 0 0 10px rgba(0,0,0,0.1);
      }
      h2 {
      font-size: 2em;
      margin-top: 0;
      text-align: center;
      grid-area: name;
      }
      .logo {
      grid-area: logo;
      margin-right: auto;
      margin-left: 0;
      }
      .logo img {
      width: 100%;
      height: 100%;
      }
      img {
      max-height: 300px;
      }
      nav {
      grid-area: nav;
      display: flex;
      justify-content: flex-start;
      }
      ul {
      list-style: none;
      margin: 0;
      padding: 0;
      display: flex;
      flex-direction: column;
      align-items: center;
      }
      li {
      margin: 0 10px;
      }
      main {
      padding: 20px;
      }
      p {
      font-size: 1.2em;
      }
      footer {
      padding: 20px;
      background-color: rgba(30,10,1,255);
      text-align: center;
      }
      .dropdown {
      position: relative;
      display: inline-block;
      transition: 1s;
      }
      .dropdown-content {
      transition: 1s;
      display: none;
      position: absolute;
      background-color: rgba(30,10,1,255);
      min-width: 160px;
      box-shadow: 0px 8px 16px 0px rgba(30,10,1,255);
      padding: 12px 16px;
      z-index: 1;
      }
      .add-to-cart-btn{
      background-color: #808080;
      color: white;
      border: none;
      padding: 8px 16px;
      border-radius: 4px;
      font-size: 16px;
      }
      .add-to-cart-btn:hover{
      background-color: #5f5f5f;
      cursor: pointer;
      }
      .dropdown:hover .dropdown-content {
      display: block;
      }
      nav li {
      transition: 1s;
      padding-bottom: 15px;
      }
      a:link {
      text-decoration: none;
      }
      a:visited {
      text-decoration: none;
      }
      a:hover {
      text-decoration: none;
      }
      a:active {
      text-decoration: none;
      }
      .product-list {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
      grid-gap: 20px;
      }
      .product {
      border: 1px solid #ccc;
      padding: 20px;
      text-align: center;
      }
      .product img {
      max-width: 100%;
      height: 200px;
      object-fit: cover; /* or "contain" depending on your preference */
      }
      .cart-modal {
      display: none;
      position: fixed;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      background-color: darkred;
      padding: 20px;
      border-radius: 5px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.3);
      }
      .cart-modal.show {
      display: block;
      }
   </style>
   <body>
      <header>
      <div class="logo">
         <img src="logo.png" alt="RIV Electronics">
      </div>
      <h2>Добре дошли в Рив Електроникс</h2>
      <nav>
         <div class="dropdown">
            <span>Меню</span>
            <div class="dropdown-content">
            <ul>
				<li><a href="Home.php">Начало</a></li>
				<li><a href="AboutUs.php">За Нас</a></li>
				<li><a href="Offers.php">Оферти</a></li>
             <li><a href="News.php">Новини</a></li>
				<li><a href="Contacts.php">Контакти</a></li>
			</ul>
            </div>
         </div>
      </nav>
      </header style #000>
      <main>
         <p>Разгледайте нашия Каталог:</p>
         <br>
         <h3>Кутии</h3>
  

         <div class="product-list">
            <div class="product">
               <form method="post" action="">
                  <img src="catalog/case1.jpg" alt="Case 1" width="300px">
                  <h4>Led Кутия</h4>
                  <p>модерен компонент за всяко геймърско или работно място.
                     кутията ще придаде уникален и стилен вид на вашия компютър. 
                  </p>
                  <p>Цена: 120Лв</p>
                  <input type="hidden" name="product_id" value="1">
                  <input type="hidden" name="product_name" value="Led Кутия">
                  <input type="hidden" name="product_price" value="120">
                  <button type="button" class="add-to-cart-btn" data-product-id="1">Купи</button>
               </form>
            </div>
            <div class="product">
               <form method="post" action="">
                  <img src="catalog/case2.jpg" alt="Case 2" idth="300px">
                  <h4>Бяла кутия</h4>
                  <p>модерен компонент за всяко работно място.
                     кутията ще придаде уникален и стилен вид на вашия компютър. 
                  </p>
                  <p>Цена: 115Лв</p>
                  <input type="hidden" name="product_id" value="2">
                  <input type="hidden" name="product_name" value="Бяла Кутия">
                  <input type="hidden" name="product_price" value="115">
                  <button type="button" class="add-to-cart-btn" data-product-id="2">Купи</button>
               </form>
            </div>
            <div class="product">
            <form method="post" action="">
               <img src="catalog/case3.jpg" alt="Case 3">
               <h4>Розова кутия</h4>
               <p> модерен компонент за всяко геймърско работно място.
                  кутията ще придаде уникален и стилен вид на вашия компютър. 
               </p>
               <p>Цена: 110Лв</p>
               <input type="hidden" name="product_id" value="3">
                  <input type="hidden" name="product_name" value="Розова Кутия">
                  <input type="hidden" name="product_price" value="110">
                  <button type="button" class="add-to-cart-btn" data-product-id="3">Купи</button>
            </form>
            </div>
         </div>
         <h3>Дънни платки</h3>
         <div class="product-list">
            <div class="product">
            <form method="post" action="">
               <img src="catalog/motherboard1.jpg" alt="Motherboard 1">
               <h4>АМ4</h4>
               <p>Тази дънна платка е съвместима с процесори от серията AMD Ryzen и осигурява бърза и стабилна работа на вашия компютър.
                  Снабдена е с най-новите технологии за охлаждане и управление на енергията, 
                  което я прави перфектен избор за геймъри и ентусиасти на компютърните технологии.
               </p>
               <p>Цена: 199Лв</p>
               <input type="hidden" name="product_id" value="4">
                  <input type="hidden" name="product_name" value="АМ4">
                  <input type="hidden" name="product_price" value="199">
                  <button type="button" class="add-to-cart-btn" data-product-id="4">Купи</button>
             </form>
            </div>
            <div class="product">
            <form method="post" action="">
               <img src="catalog/motherboard2.jpg" alt="Motherboard 2">
               <h4>LGA 1200</h4>
               <p>Тази дънна платка е съвместима с процесори от серията Intel Core i9, i7, i5 и i3
                  и е идеална за създаване на мощен компютър за игри или професионална употреба. 
                  Платката разполага с вградени функции за управление на енергията и оптимизиране на работата на компютъра.
               </p>
               <br>
               <p>Цена: 299Лв</p>
               <input type="hidden" name="product_id" value="5">
                  <input type="hidden" name="product_name" value="LGA 1200">
                  <input type="hidden" name="product_price" value="299">
                  <button type="button" class="add-to-cart-btn" data-product-id="5">Купи</button>
            </form>
            </div>
            <div class="product">
            <form method="post" action="">
               <img src="catalog/motherboard3.jpg" alt="Motherboard 3">
               <h4>TR4</h4>
               <p>Тази дънна платка е специално проектирана за процесорите 
                  AMD Ryzen Threadripper и осигурява бърза и ефективна работа на вашия компютър.
                  Разполага с най-новите технологии за
                  управление на енергията, което я прави идеален избор за потребители,
                  които изискват максимална мощност от своя компютър.
               </p>
               <p>Цена: 399Лв</p>
               <input type="hidden" name="product_id" value="6">
                  <input type="hidden" name="product_name" value="TR4">
                  <input type="hidden" name="product_price" value="399">
                  <button type="button" class="add-to-cart-btn" data-product-id="6">Купи</button>
            </div>
            </form>
         </div>
         <h3>Процесори</h3>
         <div class="product-list">
            <div class="product">
            <form method="post" action="">
               <img src="catalog/processor1.jpg" alt="Processor 1">
               <h4>Intel Core Pentium</h4>
               <p> са подходящи за бюджетни компютърни системи и осигуряват добра производителност за
                  основни приложения като уеб сърфиране, офис приложения и леки игри.
               </p>
               <p>Цена: 129Лв</p>
               <input type="hidden" name="product_id" value="7">
                  <input type="hidden" name="product_name" value="Intel Core Pentium">
                  <input type="hidden" name="product_price" value="129">
                  <button type="button" class="add-to-cart-btn" data-product-id="7">Купи</button>
            </form>
            </div>
            <div class="product">
            <form method="post" action="">
               <img src="catalog/processor2.jpg" alt="Processor 2">
               <h4>Intel Core i7</h4>
               <p>подходящи за използване в мощни компютърни системи за гейминг, 
                  видео обработка, научни изчисления и други професионални приложения. 
               </p>
               <p>Цена: 676Лв</p>
               <input type="hidden" name="product_id" value="8">
                  <input type="hidden" name="product_name" value="Intel Core i7">
                  <input type="hidden" name="product_price" value=" 676">
                  <button type="button" class="add-to-cart-btn" data-product-id="8">Купи</button>
            </form>
            </div>
            <div class="product">
            <form method="post" action="">
               <img src="catalog/processor3.jpg" alt="Processor 3">
               <h4>Intel Core i5</h4>
               <p>подходящи за използване в средно мощни компютърни системи за различни приложения,
                  включително за гейминг, мултимедия, бизнес и офис приложения.
               </p>
               <p>Цена: 471Лв</p>
               <input type="hidden" name="product_id" value="9">
                  <input type="hidden" name="product_name" value="Intel Core i5">
                  <input type="hidden" name="product_price" value="471">
                  <button type="button" class="add-to-cart-btn" data-product-id="9">Купи</button>
            </form>
            </div>
         </div>
         <h3>Охладители</h3>
         <div class="product-list">
            <div class="product">
            <form method="post" action="">
               <img src="catalog/cooler1.jpg" alt="Cooler 1">
               <h4>Въздушно охлаждане 100</h4>
               <p>малък и компактен охладител, който е идеален за по-малки компютърни системи.
                  Той е оборудван с вентилатор, който е в състояние да осигури достатъчно въздушен поток за охлаждане на процесора.
               </p>
               <p>Цена: 199Лв</p>
               <input type="hidden" name="product_id" value="10">
                  <input type="hidden" name="product_name" value="Въздушно охлаждане 100">
                  <input type="hidden" name="product_price" value="199">
                  <button type="button" class="add-to-cart-btn" data-product-id="10">Купи</button>
            </form>
            </div>
            <div class="product">
            <form method="post" action="">
               <img src="catalog/cooler2.jpg" alt="Cooler 2">
               <h4>Въздушно охлаждане 230</h4>
               <p>среден по големина охладител, който е подходящ за повечето компютърни системи. 
                  Той е оборудван с по-големи вентилатори, 
                  които осигуряват по-голям въздушен поток за охлаждане на процесора и другите компоненти.
               </p>
               <p>Цена: 229Лв</p>
               <input type="hidden" name="product_id" value="11">
                  <input type="hidden" name="product_name" value="Въздушно охлаждане 230">
                  <input type="hidden" name="product_price" value="229">
                  <button type="button" class="add-to-cart-btn" data-product-id="11">Купи</button>
            </form>
            </div>
            <div class="product">
            <form method="post" action="">
               <img src="catalog/cooler3.jpg" alt="Cooler 3">
               <h4>Въздушно охлаждане 300</h4>
               <p>голям и мощен охладител, който е подходящ за мощни гейминг компютърни системи. Той е оборудван с 
                  големи вентилатори и по-големи топлоотводящи елементи,
                  които осигуряват максимално охлаждане на процесора.
               </p>
               <p>Цена: 329Лв</p>
               <input type="hidden" name="product_id" value="12">
                  <input type="hidden" name="product_name" value="Въздушно охлаждане 300">
                  <input type="hidden" name="product_price" value="329">
                  <button type="button" class="add-to-cart-btn" data-product-id="12">Купи</button>
            </form>
            </div>
         </div>
         <h3>Памети RAM</h3>
         <div class="product-list">
            <div class="product">
            <form method="post" action="">
               <img src="catalog/ram1.jpg" alt="RAM Memory 1">
               <h4>DDR4 16GB</h4>
               <p>подходящ за повечето стандартни компютърни системи за общи приложения, като офис и интернет приложения, както и за по-леки игри.</p>
               <p>Цена: 129Лв</p>
               <input type="hidden" name="product_id" value="13">
                  <input type="hidden" name="product_name" value="DDR4 16GB">
                  <input type="hidden" name="product_price" value="129">
                  <button type="button" class="add-to-cart-btn" data-product-id="13">Купи</button>
            </form>
            </div>
            <div class="product">
            <form method="post" action="">
               <img src="catalog/ram2.jpg" alt="RAM Memory 2">
               <h4>DDR4 32GB</h4>
               <p>подходящ за по-тежки приложения, като виртуална реалност, графичен дизайн, видеообработка, музикално и звукозаписване и многозадачност.</p>
               <p>Цена: 227Лв</p>
               <input type="hidden" name="product_id" value="14">
                  <input type="hidden" name="product_name" value="DDR4 32GB">
                  <input type="hidden" name="product_price" value="227">
                  <button type="button" class="add-to-cart-btn" data-product-id="14">Купи</button>
            </form>
            </div>
            <div class="product">
            <form method="post" action="">
               <img src="catalog/ram3.jpg" alt="RAM Memory 3">
               <h4>DDR4 64GB</h4>
               <p> подходящ за най-мощните компютърни системи, като сървъри, големи работни станции и гейминг компютри, които изискват много голям капацитет на паметта.</p>
               <p>Цена: 329Лв</p>
               <input type="hidden" name="product_id" value="15">
                  <input type="hidden" name="product_name" value="DDR4 64GB">
                  <input type="hidden" name="product_price" value="329">
                  <button type="button" class="add-to-cart-btn" data-product-id="15">Купи</button>
            </form>
            </div>
         </div>
         <h3>Видео карти</h3>
         <div class="product-list">
            <div class="product">
            <form method="post" action="">
               <img src="catalog/video-card1.jpg" alt="Video Card 1">
               <h4>AMD Radeon RX 6800 XT</h4>
               <p>мощна видеокарта, която предлага високо качество на графиката и изпълнение на игрите в 4K резолюция.
                  Тя е снабдена с 16 GB GDDR6 памет и най-новата архитектура на AMD RDNA 2.
               </p>
               <br><br>
               <p>Цена: 1329Лв</p>
               <input type="hidden" name="product_id" value="16">
                  <input type="hidden" name="product_name" value="AMD Radeon RX 6800 XT">
                  <input type="hidden" name="product_price" value="1329">
                  <button type="button" class="add-to-cart-btn" data-product-id="16">Купи</button>
            </form>
            </div>
            <div class="product">
            <form method="post" action="">
               <img src="catalog/video-card2.jpg" alt="Video Card 2">
               <h4>NVIDIA GeForce RTX 3080</h4>
               <p>по-мощна видеокарта, която предлага максимално изпълнение на игрите и графичните приложения в 4K и дори в 8K резолюция. 
                  Тя е снабдена с 10.496 CUDA ядра и 10 GB GDDR6X памет, както и технологии като Ray Tracing и DLSS.
               </p>
               <p>Цена: 1539Лв</p>
               <input type="hidden" name="product_id" value="17">
                  <input type="hidden" name="product_name" value="NVIDIA GeForce RTX 3080">
                  <input type="hidden" name="product_price" value="1539">
                  <button type="button" class="add-to-cart-btn" data-product-id="17">Купи</button>
            </form>
            </div>
            <div class="product">
            <form method="post" action="">
               <img src="catalog/video-card3.jpg" alt="Video Card 3">
               <h4>NVIDIA GeForce GTX 1660</h4>
               <p> по-малко мощна видеокарта, която е предназначена за по-бюджетни геймъри и потребители на компютърни системи. 
                  Тя предлага задоволително изпълнение на игрите в 1080p и 1440p резолюция, като е снабдена с 6 GB GDDR5 памет и 1408 CUDA ядра.
               </p>
               <p>Цена: 729Лв</p>
               <input type="hidden" name="product_id" value="18">
                  <input type="hidden" name="product_name" value="NVIDIA GeForce GTX 1660">
                  <input type="hidden" name="product_price" value="729">
                  <button type="button" class="add-to-cart-btn" data-product-id="18">Купи</button>
            </form>
            </div>
         </div>
         <h3>SSD дискове</h3>
         <div class="product-list">
            <div class="product">
            <form method="post" action="">
               <img src="catalog/ssd-drive1.jpg" alt="SSD Drive 1">
               <h4>Samsung 970 EVO Plus 1TB</h4>
               <p> бърз и надежден SSD диск, който предлага скорост на четене до 3.500 MB/s и скорост на запис до 3.300 MB/s. 
                  Този диск е снабден със съвременна технология на паметта NAND и е подходящ за захранване на големи бази данни, снимки, видео материали и игри.
               </p>
               <p>Цена: 216Лв</p>
               <input type="hidden" name="product_id" value="19">
                  <input type="hidden" name="product_name" value="Samsung 970 EVO Plus 1TB">
                  <input type="hidden" name="product_price" value="216">
                  <button type="button" class="add-to-cart-btn" data-product-id="19">Купи</button>
            </form>
            </div>
            <div class="product">
            <form method="post" action="">
               <img src="catalog/ssd-drive2.jpg" alt="SSD Drive 2">
               <h4>Crucial MX500 2TB</h4>
               <p> също един отличен избор за съхранение на данни, предлагайки голям капацитет от 2TB. Той има скорост на четене до 560 MB/s и скорост на запис до 510 MB/s. 
                  Този SSD диск също така е надежден и подходящ за обработка на големи файлове.
               </p>
               <p>Цена: 416Лв</p>
               <input type="hidden" name="product_id" value="20">
                  <input type="hidden" name="product_name" value="Crucial MX500 2TB">
                  <input type="hidden" name="product_price" value="416">
                  <button type="button" class="add-to-cart-btn" data-product-id="20">Купи</button>
            </form>
            </div>
            <div class="product">
            <form method="post" action="">
               <img src="catalog/ssd-drive3.jpg" alt="SSD Drive 3">
               <h4>Kingston A2000 512GB</h4>
               <p>по-малък капацитет на SSD диск, но все пак предлага скорост на четене до 2.200 MB/s и скорост на запис до 2.000 MB/s. 
                  Този диск е снабден също с NAND технология на паметта и е 
                  подходящ за бърза зареждане на програми в операционната система на компютъра.
               </p>
               <p>Цена: 116Лв</p>
               <input type="hidden" name="product_id" value="21">
                  <input type="hidden" name="product_name" value="Kingston A2000 512GB">
                  <input type="hidden" name="product_price" value="116">
                  <button type="button" class="add-to-cart-btn" data-product-id="21">Купи</button>
            </form>
            </div>
         </div>
         <div class="cart-modal">
            <div class="cart-header">
               <h3>Поръчка</h3>
               <button class="cart-close-btn">&times;</button>
            </div>
            <div class="cart-body">
               <table>
                  <thead>
                     <tr>
                        <th>Продукт</th>
                        <th>Цена</th>
                        <th>Брой</th>
                        <th>Действие</th>
                     </tr>
                  </thead>
                  <tbody></tbody>
               </table>
            </div>
            <div class="cart-footer">
               <p>Общо: <span id="cart-total"></span></p>
               <button class="cart-clear-btn btn btn-danger">Изчисти</button>
               <button type="submit" id="order" class="cart-clear-btn btn btn-danger">Поръчай</button>
            </div>
         </div>
      </main>
    
      <footer>
         <p>&copy; 2023 Рив Електроникс. Всички права запазени.</p>
      </footer>
      <script>
   document.addEventListener('DOMContentLoaded', () => {
      const orderBtn = document.querySelector('#order');

orderBtn.addEventListener('click', () => {
  // display a message to simulate the effect of ordering
  alert('Поръчката е получена чакайте обаждане');

  // clear the cart
  for (let key in cart) {
    delete cart[key];
  }
  updateCart();
});

  const cart = {};
  
  const addToCartBtns = document.querySelectorAll('.add-to-cart-btn');
  const cartModal = document.querySelector('.cart-modal');
  const cartTableBody = cartModal.querySelector('tbody');
  const cartTotal = document.querySelector('#cart-total');
  const cartCloseBtn = cartModal.querySelector('.cart-close-btn');
  
  addToCartBtns.forEach((btn) => {
    btn.addEventListener('click', (event) => {
      const productId = event.currentTarget.getAttribute('data-product-id');
      const form = event.currentTarget.closest('form');
      const priceInput = form.querySelector('input[name="product_price"]');
      const productPrice = parseFloat(priceInput.value);
      const productNameInput = form.querySelector('input[name="product_name"]');
      const productName = productNameInput.value;
      if (cart[productId]) {
        cart[productId].quantity += 1;
      } else {
        cart[productId] = {
          quantity: 1,
          price: productPrice,
          name: productName,
        };
      }
      updateCart();
      cartModal.classList.add('show');
    });
  });
  
  function updateCart() {
    cartTableBody.innerHTML = '';
    let total = 0;
    for (const productId in cart) {
      const product = cart[productId];
      const tr = document.createElement('tr');
      const tdName = document.createElement('td');
      tdName.textContent = product.name;
      const tdPrice = document.createElement('td');
      tdPrice.textContent = product.price.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, " ") + ' лв.';
      const tdQuantity = document.createElement('td');
      const quantityInput = document.createElement('input');
      quantityInput.setAttribute('type', 'number');
      quantityInput.setAttribute('min', '1');
      quantityInput.setAttribute('value', product.quantity);
      quantityInput.addEventListener('input', (event) => {
        const newQuantity = parseInt(event.currentTarget.value);
        if (newQuantity < 1) {
          delete cart[productId];
        } else {
          cart[productId].quantity = newQuantity;
        }
        updateCart();
      });
      tdQuantity.appendChild(quantityInput);
      const tdRemove = document.createElement('td');
      const removeBtn = document.createElement('button');
      removeBtn.setAttribute('type', 'button');
      removeBtn.classList.add('btn', 'btn-danger');
      removeBtn.textContent = 'Премахни'; // change text here
      removeBtn.addEventListener('click', () => {
        delete cart[productId];
        updateCart();
      });
      tdRemove.appendChild(removeBtn);
      tr.appendChild(tdName);
      tr.appendChild(tdPrice);
      tr.appendChild(tdQuantity);
      tr.appendChild(tdRemove);
      cartTableBody.appendChild(tr);
      total += product.price * product.quantity;
    }
    cartTotal.textContent = total.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, " ") + " лв.";

  }
  
  cartCloseBtn.addEventListener('click', () => {
    cartModal.classList.remove('show');
  });
  
  document.querySelector('.cart-clear-btn').addEventListener('click', () => {
    for (let key in cart) {
      delete cart[key];
    }
    updateCart();
  });
  
  updateCart();
});

      </script>
   </body>
</html>