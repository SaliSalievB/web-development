<!DOCTYPE html>
<html>
<head>
	<title>RIV Electronics</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
</head>
<style>
    body{
        margin: 0;
        background-color: rgba(30,10,1,255);
        color: antiquewhite;
}
a {
  background-color: rgba(30,10,1,255);
  color: #fff;
  border: none;
  padding: 10px 20px;
  font-size: 16px;
  border-radius: 5px;
  cursor: pointer;
  transition: all 0.3s ease;
}

a:hover {
  background-color: #000;
  color: #fff;
}

  header {
  display: grid;
  grid-template-columns: 1fr auto 1fr;
  grid-template-rows: auto auto;
  grid-template-areas: 
    ". name nav"
    "logo name nav";
  align-items: center;
  justify-items: center;
  padding: -50px;
  background-color: rgba(30,10,1,255);
  box-shadow: 0 0 10px rgba(0,0,0,0.1);
}

h2 {
  font-size: 2em;
  margin-top: 0;
  text-align: center;
  grid-area: name;
}
.logo {
  grid-area: logo;
  margin-right: auto;
  margin-left: 0;
}

.logo img {
  width: 100%;
  height: 100%;
}

img {
	max-height: 300px;
}

nav {
  grid-area: nav;
  display: flex;
  justify-content: flex-start;
}

ul {
  list-style: none;
  margin: 0;
  padding: 0;
  display: flex;
  flex-direction: column;
  align-items: center;
}
li {
    margin: 0 10px;
}

main {
	padding: 20px;
}


p {
	font-size: 1.2em;
}

footer {
  position: absolute;
  left: 0;
  bottom: -100px;
  width: 100%;
  text-align: center;
  padding: 20px 0;
}


.dropdown {
  position: relative;
  display: inline-block;
  transition: 1s;
}

.dropdown-content {
    transition: 1s;
  display: none;
  position: absolute;
  background-color: rgba(30,10,1,255);
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(30,10,1,255);
  padding: 12px 16px;
  z-index: 1;
}

.dropdown:hover .dropdown-content {
  display: block;
}
nav li {
    transition: 1s;
  padding-bottom: 15px;
}
 a:link {
      text-decoration: none;
}

a:visited {
      text-decoration: none;
}

a:hover {
      text-decoration: none;
}

a:active {
      text-decoration: none;
}
.container {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  grid-gap: 20px;
  align-items: center;
}

.text {
  grid-column: 1 / span 1;
}

.image {
  grid-column: 2 / span 1;
  text-align: right;
}

.image img {
  max-width: 100%;
  height: auto;
}

#myImg {
  border-radius: 5px;
  cursor: pointer;
  transition: 0.3s;
}

#myImg:hover {opacity: 0.7;}

/* The Modal (background) */
.modal {
  display: none; /* Hidden by default */
  position: fixed; /* Stay in place */
  z-index: 1; /* Sit on top */
  padding-top: 100px; /* Location of the box */
  left: 0;
  top: 0;
  width: 100%; /* Full width */
  height: 100%; /* Full height */
  overflow: auto; /* Enable scroll if needed */
  background-color: rgb(0,0,0); /* Fallback color */
  background-color: rgba(0,0,0,0.9); /* Black w/ opacity */
}

/* Modal Content (Image) */
.modal-content {
  margin: auto;
  display: block;
  width: 80%;
  max-width: 700px;
}

/* Caption of Modal Image (Image Text) - Same Width as the Image */
#caption {
  margin: auto;
  display: block;
  width: 80%;
  max-width: 700px;
  text-align: center;
  color: #ccc;
  padding: 10px 0;
  height: 150px;
}

/* Add Animation - Zoom in the Modal */
.modal-content, #caption {
  animation-name: zoom;
  animation-duration: 0.6s;
}

@keyframes zoom {
  from {transform:scale(0)}
  to {transform:scale(1)}
}

/* The Close Button */
.close {
  position: absolute;
  top: 15px;
  right: 35px;
  color: #f1f1f1;
  font-size: 40px;
  font-weight: bold;
  transition: 0.3s;
}

.close:hover,
.close:focus {
  color: #bbb;
  text-decoration: none;
  cursor: pointer;
}



</style>
<body>
	<header>
		<div class="logo">
			<img src="logo.png" alt="RIV Electronics">
		</div>
        <h2>За Нас</h2>
<nav>        
        <div class="dropdown">
        <span>Меню</span>
        <div class="dropdown-content">
        <ul>
				<li><a href="Home.php">Начало</a></li>
				<li><a href="AboutUs.php">За Нас</a></li>
				<li><a href="Offers.php">Оферти</a></li>
        <li><a href="News.php">Новини</a></li>
				<li><a href="Contacts.php">Контакти</a></li>
			</ul>
        </div>
        </div>
</nav>
	</header>
	<main>
		<center class="container">
      <div class="text">
      <p>
        В Riv Electronics ние предоставяме висококачествени компютърни компоненти и отлично обслужване на клиентите в продължение на много години. Нашият опитен екип 
        е посветен на това да гарантира, че нашите клиенти получават най-добрите налични продукти и услуги.

        Ние вярваме, че нашият успех е изграден върху нашия ангажимент за качество, достъпност и надеждност. 
        Ето защо работим усилено, за да доставяме най-новите и най-иновативни продукти от доверени производители и да ги предлагаме на конкурентни цени.
      </p>
      <p>
        Нашият екип е винаги на разположение, за да отговори на всички ваши въпроси и да ви помогне да намерите идеалния продукт за вашите нужди.
         Ние също така предлагаме бързи и надеждни опции за доставка, така че можете да се насладите на новите си компоненти за нула време.
        
        Благодарим ви, че избрахте Riv Electronics като източник за всички ваши нужди от компютърни компоненти. Очакваме с нетърпение да ви обслужим
         и да ви помогнем да извлечете максимума от вашата технология.
    </p>
  </div>
    <img src="AboutUs/изтеглен файл.jpg" alt="" class="image" width="80%"  id="myImg">
    <div id="myModal" class="modal">

        <!-- The Close Button -->
        <span class="close">&times;</span>
      
        <!-- Modal Content (The Image) -->
        <img class="modal-content" id="img01">
      
        <!-- Modal Caption (Image Text) -->
        <div id="caption"></div>
      </div>
</center>
	</main>
	<footer>
		<p>&copy; 2023 Рив Електроникс. Всички права запазени.</p>
	</footer>
    <script>
          // Get the modal
          var modal = document.getElementById("myModal");

// Get the image and insert it inside the modal - use its "alt" text as a caption
var img = document.getElementById("myImg");
var modalImg = document.getElementById("img01");
var captionText = document.getElementById("caption");
img.onclick = function(){
  modal.style.display = "block";
  modalImg.src = this.src;
  captionText.innerHTML = this.alt;
}

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

// When the user clicks on <span> (x), close the modal
span.onclick = function() { 
  modal.style.display = "none";
}
    </script>
</body>
</html>
