<!DOCTYPE html>
<html>
<head>
	<title>RIV Electronics</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
</head>
<style>
    body{
        margin: 0;
        background-color: rgba(30,10,1,255);
        color: antiquewhite;
}
a {
  background-color: rgba(30,10,1,255);
  color: #fff;
  border: none;
  padding: 10px 20px;
  font-size: 16px;
  border-radius: 5px;
  cursor: pointer;
  transition: all 0.3s ease;
}

a:hover {
  background-color: #000;
  color: #fff;
}

  header {
  display: grid;
  grid-template-columns: 1fr auto 1fr;
  grid-template-rows: auto auto;
  grid-template-areas: 
    ". name nav"
    "logo name nav";
  align-items: center;
  justify-items: center;
  padding: -50px;
  background-color: rgba(30,10,1,255);
  box-shadow: 0 0 10px rgba(0,0,0,0.1);
}

h2 {
  font-size: 2em;
  margin-top: 0;
  text-align: center;
  grid-area: name;
}
.logo {
  grid-area: logo;
  margin-right: auto;
  margin-left: 0;
}

.logo img {
  width: 100%;
  height: 100%;
}

img {
	max-height: 300px;
}

nav {
  grid-area: nav;
  display: flex;
  justify-content: flex-start;
}

ul {
  list-style: none;
  margin: 0;
  padding: 0;
  display: flex;
  flex-direction: column;
  align-items: center;
}
li {
    margin: 0 10px;
}

main {
	padding: 20px;
}


p {
	font-size: 1.2em;
}

footer {
  position: fixed;
  left: 0;
  bottom: 0;
  width: 100%;
  text-align: center;
  padding: 20px 0;
}

.dropdown {
  position: relative;
  display: inline-block;
  transition: 1s;
}

.dropdown-content {
    transition: 1s;
  display: none;
  position: absolute;
  background-color: rgba(30,10,1,255);
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(30,10,1,255);
  padding: 12px 16px;
  z-index: 1;
}

.dropdown:hover .dropdown-content {
  display: block;
}
nav li {
    transition: 1s;
  padding-bottom: 15px;
}
 a:link {
      text-decoration: none;
}

a:visited {
      text-decoration: none;
}

a:hover {
      text-decoration: none;
}

a:active {
      text-decoration: none;
}
.container {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  grid-gap: 20px;
  align-items: center;
}

.text {
  grid-column: 1 / span 1;
}

.image {
  grid-column: 2 / span 1;
  text-align: right;
}

.image img {
  max-width: 100%;
  height: auto;
}

.login-box {
  position: absolute;
  top: 55%;
  left: 50%;
  width: 380px;
  padding: 40px;
  transform: translate(-50%, -50%);
  background: rgba(0,0,0,.5);
  box-sizing: border-box;
  box-shadow: 0 15px 25px rgba(0,0,0,.6);
  border-radius: 10px;
}

.login-box h2 {
  margin: 0 0 30px;
  padding: 0;
  color: #fff;
  text-align: center;
}

.login-box .user-box {
  position: relative;
}

.login-box .user-box input {
  width: 100%;
  padding: 10px 0;
  font-size: 16px;
  color: #fff;
  margin-bottom: 30px;
  border: none;
  border-bottom: 1px solid #fff;
  outline: none;
  background: transparent;
}
.login-box .user-box label {
  position: absolute;
  top:0;
  left: 0;
  padding: 10px 0;
  font-size: 16px;
  color: #fff;
  pointer-events: none;
  transition: .5s;
}

.login-box .user-box input:focus ~ label,
.login-box .user-box input:valid ~ label {
  top: -20px;
  left: 0;
  color: #03e9f4;
  font-size: 12px;
}

.login-box form a {
  position: relative;
  display: inline-block;
  padding: 10px 20px;
  color: #03e9f4;
  font-size: 16px;
  text-decoration: none;
  text-transform: uppercase;
  overflow: hidden;
  transition: .5s;
  margin-top: 40px;
  letter-spacing: 4px
}

.login-box a:hover {
  background: #03e9f4;
  color: #fff;
  border-radius: 5px;
  box-shadow: 0 0 5px #03e9f4,
              0 0 25px #03e9f4,
              0 0 50px #03e9f4,
              0 0 100px #03e9f4;
}

.login-box a span {
  position: absolute;
  display: block;
}

.login-box a span:nth-child(1) {
  top: 0;
  left: -100%;
  width: 100%;
  height: 2px;
  background: linear-gradient(90deg, transparent, #03e9f4);
  animation: btn-anim1 1s linear infinite;
}

@keyframes btn-anim1 {
  0% {
    left: -100%;
  }
  50%,100% {
    left: 100%;
  }
}

.login-box a span:nth-child(2) {
  top: -100%;
  right: 0;
  width: 2px;
  height: 100%;
  background: linear-gradient(180deg, transparent, #03e9f4);
  animation: btn-anim2 1s linear infinite;
  animation-delay: .25s
}

@keyframes btn-anim2 {
  0% {
    top: -100%;
  }
  50%,100% {
    top: 100%;
  }
}

.login-box a span:nth-child(3) {
  bottom: 0;
  right: -100%;
  width: 90%;
  height: 2px;
  background: linear-gradient(270deg, transparent, #03e9f4);
  animation: btn-anim3 1s linear infinite;
  animation-delay: .5s
}

@keyframes btn-anim3 {
  0% {
    right: -100%;
  }
  50%,100% {
    right: 100%;
  }
}

.login-box a span:nth-child(4) {
  bottom: -100%;
  left: 0;
  width: 2px;
  height: 100%;
  background: linear-gradient(360deg, transparent, #03e9f4);
  animation: btn-anim4 1s linear infinite;
  animation-delay: .75s
}

@keyframes btn-anim4 {
  0% {
    bottom: -100%;
  }
  50%,100% {
    bottom: 100%;
  }
}
</style>
<body>
	<header>
		<div class="logo">
			<img src="logo.png" alt="RIV Electronics">
		</div>
        <h2>Добре дошли в Рив Електроникс</h2>
<nav>        
        <div class="dropdown">
        <span>Меню</span>
        <div class="dropdown-content">
        <ul>
				<li><a href="Home.php">Начало</a></li>
				<li><a href="AboutUs.php">За Нас</a></li>
				<li><a href="Offers.php">Оферти</a></li>
        <li><a href="News.php">Новини</a></li>
				<li><a href="Contacts.php">Контакти</a></li>
			</ul>
        </div>
        </div>
</nav>
	</header>
	<main>
  <div class="login-box">
            <h2>Свържете се със нас</h2>
            <form action="" method="post">
              <div class="user-box">
                <input type="text" name="" required="">
                <label>Име</label>
              </div>
              <div class="user-box">
                <input type="email" name="" required="">
                <label>Имейл</label>
              </div>
              <div class="user-box">
                <input type="number" id="phone" name="phone" required="">
                <label>Номер</label>
              </div>
              <div class="user-box">
                <input type="text" name="" required="">
                <label>Съобщение</label>
              </div>
              <center>
              <button type="submit" class="btn btn-primary">Изпрати</button>
            </center>
            </form>
          </div>
	</main>
	<footer>
		<p>&copy; 2023 Рив Електроникс. Всички права запазени.</p>
	</footer>
  <script>

</script>
</body>
</html>
