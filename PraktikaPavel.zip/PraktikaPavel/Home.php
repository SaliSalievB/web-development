<!DOCTYPE html>
<html>
<head>
	<title>RIV Electronics</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
</head>
<style>
    body{
        margin: 0;
        background-color: rgba(30,10,1,255);
        color: antiquewhite;
}
a {
  background-color: rgba(30,10,1,255);
  color: #fff;
  border: none;
  padding: 10px 20px;
  font-size: 16px;
  border-radius: 5px;
  cursor: pointer;
  transition: all 0.3s ease;
}

a:hover {
  background-color: #000;
  color: #fff;
}

  header {
  display: grid;
  grid-template-columns: 1fr auto 1fr;
  grid-template-rows: auto auto;
  grid-template-areas: 
    ". name nav"
    "logo name nav";
  align-items: center;
  justify-items: center;
  padding: -50px;
  background-color: rgba(30,10,1,255);
  box-shadow: 0 0 10px rgba(0,0,0,0.1);
}

h2 {
  font-size: 2em;
  margin-top: 0;
  text-align: center;
  grid-area: name;
}
.logo {
  grid-area: logo;
  margin-right: auto;
  margin-left: 0;
}

.logo img {
  width: 100%;
  height: 100%;
}

img {
	max-height: 300px;
}

nav {
  grid-area: nav;
  display: flex;
  justify-content: flex-start;
}

ul {
  list-style: none;
  margin: 0;
  padding: 0;
  display: flex;
  flex-direction: column;
  align-items: center;
}
li {
    margin: 0 10px;
}

main {
	padding: 20px;
}


p {
	font-size: 1.2em;
}

footer {
  position: absolute;
  left: 0;
  bottom: -140px;
  width: 100%;
  text-align: center;
  padding: 20px 0;
}

.dropdown {
  position: relative;
  display: inline-block;
  transition: 1s;
}

.dropdown-content {
    transition: 1s;
  display: none;
  position: absolute;
  background-color: rgba(30,10,1,255);
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(30,10,1,255);
  padding: 12px 16px;
  z-index: 1;
}

.dropdown:hover .dropdown-content {
  display: block;
}
nav li {
    transition: 1s;
  padding-bottom: 15px;
}
 a:link {
      text-decoration: none;
}

a:visited {
      text-decoration: none;
}

a:hover {
      text-decoration: none;
}

a:active {
      text-decoration: none;
}
.container {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  grid-gap: 20px;
  align-items: center;
}

.text {
  grid-column: 1 / span 1;
}

.image {
  grid-column: 2 / span 1;
  text-align: right;
}

.image img {
  max-width: 100%;
  height: auto;
}

</style>
<body>
	<header>
		<div class="logo">
			<img src="logo.png" alt="RIV Electronics">
		</div>
        <h2>Добре дошли в Рив Електроникс</h2>
<nav>        
        <div class="dropdown">
        <span>Меню</span>
        <div class="dropdown-content">
        <ul>
				<li><a href="Home.php">Начало</a></li>
				<li><a href="AboutUs.php">За Нас</a></li>
				<li><a href="Offers.php">Оферти</a></li>
        <li><a href="News.php">Новини</a></li>
				<li><a href="Contacts.php">Контакти</a></li>
			</ul>
        </div>
        </div>
</nav>
	</header>
	<main>
		<center class="container">
      <div class="text">
      <p>
       Добре дошли в Riv Electronics. Ние предлагаме широка гама от продукти, включително кутии,
       дънни платки, процесори, охладители, RAM, видео карти, SSD устройства и др. Нашият уебсайт 
       представя всички наши налични продукти, категоризирани по тип, и включва информация за наличност, 
       спецификации, цени и изображения.
      </p>
      <p>
      Нашият ангажимент за качество и удовлетвореност на клиентите е това, което ни отличава от конкуренцията. 
      Ние се гордеем с предоставянето на отлично обслужване на клиентите и се стремим да направим вашето пазаруване 
      възможно най-гладко и лесно.
    </p>
  </div>
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2968.2460298496176!2d25.556714215034145!3d41.93056437010907!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x14ad50ce8663b681%3A0x9c8da23ff3992b04!2z0KDQmNCS0J7QkiDQldCb0JXQmtCi0KDQntCd0JjQmtCh!5e0!3m2!1sbg!2sbg!4v1680101483720!5m2!1sbg!2sbg" 
    width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade" class="image"></iframe>
    </center>
	</main>
	<footer>
		<p>&copy; 2023 Рив Електроникс. Всички права запазени.</p>
	</footer>
</body>
</html>
