<!DOCTYPE html>
<html>
  <head>
    <title>Lesson Page</title>
    <style>
      body {
        font-family: Arial, sans-serif;
        background-color: #f0f0f0;
        margin: 0;
        padding: 0;
      }
      
      header {
        background-color: #007bff;
        color: #fff;
        padding: 20px;
        text-align: center;
      }
      
      h1 {
        
        margin: 0;
        font-size: 36px;
      }
      
      main {
        margin: 20px;
      }
      
      section {
        background-color: #fff;
        border: 1px solid #ccc;
        border-radius: 5px;
        padding: 10px;
        margin-bottom: 20px;
      }
      
      h2 {
        font-size: 24px;
        margin-top: 0;
      }
      
      p {
        font-size: 16px;
        line-height: 1.5;
      }
      
      ul {
        margin: 0;
        padding: 0;
        list-style: none;
      }
      
      li {
        margin-bottom: 10px;
      }
      
      a {
        color: #333;
        text-decoration: none;
        font-weight: bold;
      }
      
      a:hover {
        text-decoration: underline;
      }
      
      footer {
  background-color: #007bff;
  color: #fff;
  padding: 1rem;
  text-align: center;
  position: absolute;
  left: 0;
  bottom: -100px;
  width: 100%;
  text-align: center;
  padding: 20px 0;
  margin: 0;
  font-size: 1rem;
}
a:link {
      text-decoration: none;
      color: black;
}

a:visited {
      text-decoration: none;
      color: black;
}

a:hover {
    color: black;
      text-decoration: none;
}

a:active {
    color: black;
      text-decoration: none;
}

ul{
	display: flex;
	height: 30vh;
	margin: auto;
	justify-content: space-between;
	text-align: center;
}
li {
	padding: 1rem 2rem 1.15rem;
  text-transform: uppercase;
  cursor: pointer;
  color: black;
	min-width: 80px;
	margin: auto;
}

li:hover {
  background-image: url('https://scottyzen.sirv.com/Images/v/button.png');
  background-size: 100% 100%;
  color: #27262c;
  animation: spring 300ms ease-out;
  text-shadow: 0 -1px 0 #ef816c;
	font-weight: bold;
}
li:active {
  transform: translateY(4px);
}
    </style>
  </head>
  <body>
    <header>
      <h1>Задача за упражнение</h1>
    </header>
    
    <main>
      <section>
      <p>
      Задачата за упражнение включва изграждането на уеб страница за регистрация на потребители в 
      система за управление на задачи. <br>
      Системата трябва да позволява на потребителите да създават профил в системата, 
      да създават и управляват задачи и да получават уведомления за изминали задачи.<br>

Страницата трябва да съдържа формуляр за регистрация на потребител, който включва полета за име, фамилия, 
потребителско име, парола и потвърждение на паролата. <br>
Формулярът трябва да използва метод POST и да се валидира на страната на сървъра за да се уверите, че всички полета са 
попълнени правилно.<br>

След успешна регистрация на потребител, трябва да бъдат създадени бисквитки и сесия, 
които да се използват за автентикация на потребителя.<br> За да се генерират случайни ключове,
 може да използвате функцията rand() в PHP.<br>

Страницата трябва да има също така формуляр за добавяне на задача,
 който включва полета за име на задачата, описание, дата на изпълнение и приоритет. <br>
 Потребителят трябва да има възможност да вижда всички задачи, които е добавил, както и да ги редактира или изтрие.<br>

За да се запазват данните за потребителите и задачите, може да използвате текстови файлове или база данни. <br>
Ако използвате текстови файлове, трябва да се уверите, 
че съответните файлове имат правилните разрешения за запис и четене от уеб сървъра.<br>


За да се уведомява потребителят за изминалите задачи, можете да използвате крон джоб,
 който да проверява базата данни за задачи с изминала дата на изпълнение и да изпраща електронни писма до потребителите,
  свързани с тези задачи.
    </p>
      </section>
    </main>
    <nav>
    <ul>
            <li><a href="index.php">Начало</a></li>
			<li><a href="lessons.php">Уроци</a></li>
			<li><a href="lesson13.php">Следващ Урок</a></li>
			<li><a href="lesson11.php">Предишен Урок</a></li>
</ul>
    </nav>
    <footer>
    <p>&copy; 2023 Система за самообучение по PHP</p>
    </footer>
  </body>
</html> 