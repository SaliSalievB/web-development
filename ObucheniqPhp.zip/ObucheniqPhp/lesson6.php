<!DOCTYPE html>
<html>
  <head>
    <title>Lesson Page</title>
    <style>
      body {
        font-family: Arial, sans-serif;
        background-color: #f0f0f0;
        margin: 0;
        padding: 0;
      }
      
      header {
        background-color: #007bff;
        color: #fff;
        padding: 20px;
        text-align: center;
      }
      
      h1 {
        
        margin: 0;
        font-size: 36px;
      }
      
      main {
        margin: 20px;
      }
      
      section {
        background-color: #fff;
        border: 1px solid #ccc;
        border-radius: 5px;
        padding: 10px;
        margin-bottom: 20px;
      }
      
      h2 {
        font-size: 24px;
        margin-top: 0;
      }
      
      p {
        font-size: 16px;
        line-height: 1.5;
      }
      
      ul {
        margin: 0;
        padding: 0;
        list-style: none;
      }
      
      li {
        margin-bottom: 10px;
      }
      
      a {
        color: #333;
        text-decoration: none;
        font-weight: bold;
      }
      
      a:hover {
        text-decoration: underline;
      }
      
      footer {
  background-color: #007bff;
  color: #fff;
  padding: 1rem;
  text-align: center;
  position: absolute;
  left: 0;
  bottom: -420px;
  width: 100%;
  text-align: center;
  padding: 20px 0;
  margin: 0;
  font-size: 1rem;
}
a:link {
      text-decoration: none;
      color: black;
}

a:visited {
      text-decoration: none;
      color: black;
}

a:hover {
    color: black;
      text-decoration: none;
}

a:active {
    color: black;
      text-decoration: none;
}

ul{
	display: flex;
	height: 30vh;
	margin: auto;
	justify-content: space-between;
	text-align: center;
}
li {
	padding: 1rem 2rem 1.15rem;
  text-transform: uppercase;
  cursor: pointer;
  color: black;
	min-width: 80px;
	margin: auto;
}

li:hover {
  background-image: url('https://scottyzen.sirv.com/Images/v/button.png');
  background-size: 100% 100%;
  color: #27262c;
  animation: spring 300ms ease-out;
  text-shadow: 0 -1px 0 #ef816c;
	font-weight: bold;
}
li:active {
  transform: translateY(4px);
}
#answer{
    display: none;
}
    </style>
  </head>
  <body>
    <header>
      <h1>Задача за упражнение</h1>
    </header>
    
    <main>
      <section>
      <p>
      Да се напише скрипт, който да изчисли средната оценка на ученик по 5 предмета: 
      <br>
      математика, физика, български език, английски език и история. 
      <br>
      Оценките са цели числа от 2 до 6.
<br>
След като скриптът изчисли средната оценка, да се изведе съобщение за успеха на ученика според следната таблица:
<br>
Ако средната оценка е по-голяма или равна на 5.50, да се изведе "Отличен успех!".
<br>
Ако средната оценка е по-голяма или равна на 4.50, но по-малка от 5.50, да се изведе "Добър успех!".
<br>
Ако средната оценка е по-голяма или равна на 3.50, но по-малка от 4.50, да се изведе "Среден успех!".
<br>
Ако средната оценка е по-малка от 3.50, да се изведе "Слаб успех!".
<br>
Допълнително, да се запишат оценките на ученика в масив и да се изведе списък с тези оценки.
<br>
<h4>Когато сте готови или искате да видите правилния отговор натиснете бутона доло</h4>
<Button type="button" id="show">Клик</Button><br>
<div id="answer">
$matematika = 4;<br>
$fizika = 5;<br>
$bulgarski = 6;<br>
$angliiski = 5;<br>
$istoriq = 3;<br>
<br>
$ocenki = array($matematika, $fizika, $bulgarski, $angliiski, $istoriq);<br>
$sredna_ocenka = array_sum($ocenki) / count($ocenki);<br>
<br>
echo "Средна оценка: " . number_format($sredna_ocenka, 1) . "\n";<br>
<br>
if ($sredna_ocenka >= 5.50) {<br>
    echo "Отличен успех!\n";<br>
} elseif ($sredna_ocenka >= 4.50) {<br>
    echo "Добър успех!\n";<br>
} elseif ($sredna_ocenka >= 3.50) {<br>
    echo "Среден успех!\n";<br>
} else {<br>
    echo "Слаб успех!\n";<br>
}<br>
<br>
echo "Оценки: " . implode(" ", $ocenki) .
</div>
    </p>
      </section>
    </main>
    <nav>
    <ul>
            <li><a href="index.php">Начало</a></li>
			<li><a href="lessons.php">Уроци</a></li>
			<li><a href="lesson7.php">Следващ Урок</a></li>
			<li><a href="lesson5.php">Предишен Урок</a></li>
</ul>
    </nav>
    <footer>
    <p>&copy; 2023 Система за самообучение по PHP</p>
    </footer>
    <script>
        document.getElementById("show").addEventListener("click", function() {
  document.getElementById("answer").style.display = "block";
});

    </script>
  </body>
</html> 