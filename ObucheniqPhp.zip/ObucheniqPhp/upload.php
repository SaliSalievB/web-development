<?php
function uploadFile($file, $uploadDirectory)
{
    // Генериране на уникално име за файла
    $fileName = uniqid() . '_' . $file['name'];

    // Преместване на файла в директорията за качени файлове
    $uploadPath = $uploadDirectory . DIRECTORY_SEPARATOR . $fileName;
    if (!move_uploaded_file($file['tmp_name'], $uploadPath)) {
        die('Възникна грешка при запазването на файла.');
    }

    return $fileName;
}

// Примерно извикване на функцията
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['file'])) {
    $uploadDirectory = 'C:\xampp\htdocs\ObucheniqPhp'; // Папка за качване на файлове
    $uploadedFileName = uploadFile($_FILES['file'], $uploadDirectory);
    $downloadLink = 'http://' . $_SERVER['HTTP_HOST'] . '/' . $uploadedFileName;
    echo 'Файлът е качен успешно с име ' . $uploadedFileName . '<br>';
    echo 'Можете да го изтеглите от тук: <a href="' . $downloadLink . '">' . $downloadLink . '</a>';
}
?>
