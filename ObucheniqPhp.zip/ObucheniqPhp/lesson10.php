<!DOCTYPE html>
<html>
  <head>
    <title>Lesson Page</title>
    <style>
      body {
        font-family: Arial, sans-serif;
        background-color: #f0f0f0;
        margin: 0;
        padding: 0;
      }
      
      header {
        background-color: #007bff;
        color: #fff;
        padding: 20px;
        text-align: center;
      }
      
      h1 {
        
        margin: 0;
        font-size: 36px;
      }
      
      main {
        margin: 20px;
      }
      
      section {
        background-color: #fff;
        border: 1px solid #ccc;
        border-radius: 5px;
        padding: 10px;
        margin-bottom: 20px;
      }
      
      h2 {
        font-size: 24px;
        margin-top: 0;
      }
      
      p {
        font-size: 16px;
        line-height: 1.5;
      }
      
      ul {
        margin: 0;
        padding: 0;
        list-style: none;
      }
      
      li {
        margin-bottom: 10px;
      }
      
      a {
        color: #333;
        text-decoration: none;
        font-weight: bold;
      }
      
      a:hover {
        text-decoration: underline;
      }
      
      footer {
  background-color: #007bff;
  color: #fff;
  padding: 1rem;
  text-align: center;
  position: absolute;
  left: 0;
  bottom: -250px;
  width: 100%;
  text-align: center;
  padding: 20px 0;
  margin: 0;
  font-size: 1rem;
}
a:link {
      text-decoration: none;
      color: black;
}

a:visited {
      text-decoration: none;
      color: black;
}

a:hover {
    color: black;
      text-decoration: none;
}

a:active {
    color: black;
      text-decoration: none;
}

ul{
	display: flex;
	height: 30vh;
	margin: auto;
	justify-content: space-between;
	text-align: center;
}
li {
	padding: 1rem 2rem 1.15rem;
  text-transform: uppercase;
  cursor: pointer;
  color: black;
	min-width: 80px;
	margin: auto;
}

li:hover {
  background-image: url('https://scottyzen.sirv.com/Images/v/button.png');
  background-size: 100% 100%;
  color: #27262c;
  animation: spring 300ms ease-out;
  text-shadow: 0 -1px 0 #ef816c;
	font-weight: bold;
}
li:active {
  transform: translateY(4px);
}
    </style>
  </head>
  <body>
    <header>
      <h1>Бисквитки и сесии в PHP</h1>
    </header>
    
    <main>
      <section>
      <p>
      Бисквитките и сесиите са два механизма, които позволяват на PHP приложенията да запазят информацията на потребителите 
       между различни заявки към уеб сървъра.<br>

Бисквитките (cookies) са малки текстови файлове, които се съхраняват на компютъра на потребителя.
 Те се използват за запазване на информация, която трябва да бъде запомнена между различни посещения на уебсайта.<br>
  PHP приложението може да създаде бисквитка, като зададе име, стойност, срок на годност и др. След като бисквитката е 
  създадена, тя може да бъде използвана от браузъра на потребителя при следващо посещение на уебсайта. <br>
  За да създадете бисквитка в PHP, можете да използвате функцията setcookie().<br>


setcookie('username', 'JohnDoe', time() + (86400 * 30), '/');<br>
Тази функция създава бисквитка с име 'username', стойност 'JohnDoe', срок на годност един месец (в секунди) и път '/'.<br>
 Последният параметър определя пътя на уебсайта, за който бисквитката е валидна.<br>

Сесиите (sessions) са друг механизъм, който позволява на PHP приложенията да запазват информацията на 
потребителите между различни заявки към уеб сървъра.<br> В отличие от бисквитките, информацията в сесиите се съхранява на
 сървъра, а не на компютъра на потребителя. Когато потребителят посещава уебсайта, PHP приложението създава уникален идентификатор
  за сесията и използва го за запазване на информацията на потребителя.<br> Тази информация може да бъде достъпна от всяка страница на 
  уебсайта, като се използва специален механизъм за сесии. За да създадете сесия в PHP, трябва да използвате функцията session_start().
<br>
$_SESSION['username'] = 'JohnDoe';<br>
Тази функция стартира сесията и създава масив $_SESSION, който може да бъде използван за запазване на информация за потребителя. <br>
В този случай, информацията е потребителското име 'JohnDoe'. След като сесията е стартирана и информацията е
 запазена, тя може да бъде достъпна на всяка страница на уебсайта чрез масива $_SESSION.<br>

И двете тези технологии могат да бъдат използвани за запазване на информация за потребителите 
между различните заявки към уебсървъра. <br>Въпреки това, трябва да се има предвид, че информацията, 
която се съхранява в бисквитки, е достъпна и от други уебсайтове, които се посещават от потребителя. <br>
Това не е така при сесиите, където информацията се съхранява само на сървъра и не може да бъде достъпна от други уебсайтове.
    </p>
      </section>
    </main>
    <nav>
    <ul>
            <li><a href="index.php">Начало</a></li>
			<li><a href="lessons.php">Уроци</a></li>
			<li><a href="lesson11.php">Следващ Урок</a></li>
			<li><a href="lesson9.php">Предишен Урок</a></li>
</ul>
    </nav>
    <footer>
    <p>&copy; 2023 Система за самообучение по PHP</p>
    </footer>
  </body>
</html> 