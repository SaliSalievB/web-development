<!DOCTYPE html>
<html>
  <head>
    <title>Lesson Page</title>
    <style>
      body {
        font-family: Arial, sans-serif;
        background-color: #f0f0f0;
        margin: 0;
        padding: 0;
      }
      
      header {
        background-color: #007bff;
        color: #fff;
        padding: 20px;
        text-align: center;
      }
      
      h1 {
        
        margin: 0;
        font-size: 36px;
      }
      
      main {
        margin: 20px;
      }
      
      section {
        background-color: #fff;
        border: 1px solid #ccc;
        border-radius: 5px;
        padding: 10px;
        margin-bottom: 20px;
      }
      
      h2 {
        font-size: 24px;
        margin-top: 0;
      }
      
      p {
        font-size: 16px;
        line-height: 1.5;
      }
      
      ul {
        margin: 0;
        padding: 0;
        list-style: none;
      }
      
      li {
        margin-bottom: 10px;
      }
      
      a {
        color: #333;
        text-decoration: none;
        font-weight: bold;
      }
      
      a:hover {
        text-decoration: underline;
      }
      
      footer {
  background-color: #007bff;
  color: #fff;
  padding: 1rem;
  text-align: center;
  position: absolute;
  left: 0;
  bottom: -430px;
  width: 100%;
  text-align: center;
  padding: 20px 0;
  margin: 0;
  font-size: 1rem;
}
a:link {
      text-decoration: none;
      color: black;
}

a:visited {
      text-decoration: none;
      color: black;
}

a:hover {
    color: black;
      text-decoration: none;
}

a:active {
    color: black;
      text-decoration: none;
}

ul{
	display: flex;
	height: 30vh;
	margin: auto;
	justify-content: space-between;
	text-align: center;
}
li {
	padding: 1rem 2rem 1.15rem;
  text-transform: uppercase;
  cursor: pointer;
  color: black;
	min-width: 80px;
	margin: auto;
}

li:hover {
  background-image: url('https://scottyzen.sirv.com/Images/v/button.png');
  background-size: 100% 100%;
  color: #27262c;
  animation: spring 300ms ease-out;
  text-shadow: 0 -1px 0 #ef816c;
	font-weight: bold;
}
li:active {
  transform: translateY(4px);
}
    </style>
  </head>
  <body>
    <header>
      <h1>Свързване към база данни в PHP</h1>
    </header>
    
    <main>
      <section>
      <p>
    За да свържете PHP приложението си към база данни, трябва да използвате функциите за работа с бази данни, които PHP предоставя. <br>
       Най-често използваните бази данни в PHP са MySQL, PostgreSQL, SQLite и Microsoft SQL Server.<br>

За да свържете към база данни, трябва да посочите хост, потребителско име, парола и името на базата данни. <br>
В PHP това става с функцията mysqli_connect() или PDO::__construct(),
в зависимост от това коя библиотека за работа с бази данни използвате.<br>

Пример с mysqli_connect():<br>


$host = "localhost";<br>
$username = "myusername";<br>
$password = "mypassword";<br>
$dbname = "mydatabase";<br>

// Свързване към базата данни<br>
$conn = mysqli_connect($host, $username, $password, $dbname);<br>

// Проверка за грешки при свързването<br>
if (!$conn) {<br>
    die("Connection failed: " . mysqli_connect_error());<br>
}<br>

echo "Connected successfully";<br>
След като свържете към базата данни, можете да използвате функциите за заявки за да извлечете или да промените данни. <br>Например, 
ако искате да извлечете всички редове от таблица "users", можете да използвате следната заявка:<br>


$sql = "SELECT * FROM users";<br>
$result = mysqli_query($conn, $sql);<br>

if (mysqli_num_rows($result) > 0) {<br>
    // Обработка на резултата<br>
    while($row = mysqli_fetch_assoc($result)) {<br>
        echo "ID: " . $row["id"] . " - Name: " . $row["name"] . "<'br>";<br>
    }<br>
} else {<br>
    echo "0 results";<br>
}<br>
Тази заявка използва функцията mysqli_query() за да изпрати заявката към базата данни и да получи резултата. <br>
След това използва функцията mysqli_num_rows() за да провери дали има резултати и функцията mysqli_fetch_assoc() 
за да извлече данните от всяко едно ред в асоциативен масив.
    </p>
      </section>
    </main>
    <nav>
    <ul>
            <li><a href="index.php">Начало</a></li>
			<li><a href="lessons.php">Уроци</a></li>
			<li><a href="lesson16.php">Следващ Урок</a></li>
			<li><a href="lesson14.php">Предишен Урок</a></li>
</ul>
    </nav>
    <footer>
    <p>&copy; 2023 Система за самообучение по PHP</p>
    </footer>
  </body>
</html> 