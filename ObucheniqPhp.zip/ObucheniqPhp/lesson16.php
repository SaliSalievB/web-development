<!DOCTYPE html>
<html>
  <head>
    <title>Lesson Page</title>
    <style>
      body {
        font-family: Arial, sans-serif;
        background-color: #f0f0f0;
        margin: 0;
        padding: 0;
      }
      
      header {
        background-color: #007bff;
        color: #fff;
        padding: 20px;
        text-align: center;
      }
      
      h1 {
        
        margin: 0;
        font-size: 36px;
      }
      
      main {
        margin: 20px;
      }
      
      section {
        background-color: #fff;
        border: 1px solid #ccc;
        border-radius: 5px;
        padding: 10px;
        margin-bottom: 20px;
      }
      
      h2 {
        font-size: 24px;
        margin-top: 0;
      }
      
      p {
        font-size: 16px;
        line-height: 1.5;
      }
      
      ul {
        margin: 0;
        padding: 0;
        list-style: none;
      }
      
      li {
        margin-bottom: 10px;
      }
      
      a {
        color: #333;
        text-decoration: none;
        font-weight: bold;
      }
      
      a:hover {
        text-decoration: underline;
      }
      
      footer {
  background-color: #007bff;
  color: #fff;
  padding: 1rem;
  text-align: center;
  position: absolute;
  left: 0;
  bottom: -300px;
  width: 100%;
  text-align: center;
  padding: 20px 0;
  margin: 0;
  font-size: 1rem;
}
a:link {
      text-decoration: none;
      color: black;
}

a:visited {
      text-decoration: none;
      color: black;
}

a:hover {
    color: black;
      text-decoration: none;
}

a:active {
    color: black;
      text-decoration: none;
}

ul{
	display: flex;
	height: 30vh;
	margin: auto;
	justify-content: space-between;
	text-align: center;
}
li {
	padding: 1rem 2rem 1.15rem;
  text-transform: uppercase;
  cursor: pointer;
  color: black;
	min-width: 80px;
	margin: auto;
}

li:hover {
  background-image: url('https://scottyzen.sirv.com/Images/v/button.png');
  background-size: 100% 100%;
  color: #27262c;
  animation: spring 300ms ease-out;
  text-shadow: 0 -1px 0 #ef816c;
	font-weight: bold;
}
li:active {
  transform: translateY(4px);
}
    </style>
  </head>
  <body>
    <header>
      <h1>Изпращане на имейли с PHP</h1>
    </header>
    
    <main>
      <section>
      <p>
      Изпращането на имейли е честа задача в уеб приложенията, които често изискват да изпращат потвърждения на регистрации, 
       възстановяване на пароли и други подобни съобщения на потребителите.<br>
       PHP предоставя вградена функционалност за изпращане на имейли чрез функцията mail().<br>

Функцията mail() приема три параметъра: адрес на получателя, тема на имейла и съдържанието на имейла.<br>
 Пример за изпращане на имейл: <br>


$to = "recipient@example.com";<br>
$subject = "Test email";<br>
$message = "This is a test email.";<br>

mail($to, $subject, $message);<br>
В горния пример са подадени само адрес на получателя, тема и съобщение, но функцията mail() 
поддържа и други параметри като:<br>

From - задава имейл адреса на изпращача.<br>
Headers - задава допълнителни заглавки към имейла, като например отговорен имейл адрес, важност на съобщението и други.<br>
Attachments - прикрепя файлове към имейла.<br>
Пример за изпращане на имейл с допълнителни параметри:<br>


$to = "recipient@example.com";<br>
$subject = "Test email";<br>
$message = "This is a test email.";<br>
$headers = "From: sender@example.com\r\n";<br>
$headers .= "Reply-To: sender@example.com\r\n";<br>
$headers .= "Importance: High\r\n";<br>

mail($to, $subject, $message, $headers);<br>
В горния пример са зададени отговорен имейл адрес и важност на съобщението, като са използвани заглавки във формата 
"Заглавие: Стойност\r\n".<br>

За да се осигури успешното изпращане на имейли, е необходимо да се проверят настройките на SMTP сървъра на хостинга и да се уверите,
 че функцията mail() е разрешена на сървъра. <br>
 Така също е добра практика да се включва проверка за валидност на имейл адресите и съобщенията, които се изпращат,
  за да се избегнат грешки и проблеми при изпращането.
    </p>
      </section>
    </main>
    <nav>
    <ul>
            <li><a href="index.php">Начало</a></li>
			<li><a href="lessons.php">Уроци</a></li>
			<li><a href="lesson17.php">Следващ Урок</a></li>
			<li><a href="lesson15.php">Предишен Урок</a></li>
</ul>
    </nav>
    <footer>
    <p>&copy; 2023 Система за самообучение по PHP</p>
    </footer>
  </body>
</html> 