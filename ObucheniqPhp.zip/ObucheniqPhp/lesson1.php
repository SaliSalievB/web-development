<!DOCTYPE html>
<html>
  <head>
    <title>Lesson Page</title>
    <style>
      body {
        font-family: Arial, sans-serif;
        background-color: #f0f0f0;
        margin: 0;
        padding: 0;
      }
      
      header {
        background-color: #007bff;
        color: #fff;
        padding: 20px;
        text-align: center;
      }
      
      h1 {
        
        margin: 0;
        font-size: 36px;
      }
      
      main {
        margin: 20px;
      }
      
      section {
        background-color: #fff;
        border: 1px solid #ccc;
        border-radius: 5px;
        padding: 10px;
        margin-bottom: 20px;
      }
      
      h2 {
        font-size: 24px;
        margin-top: 0;
      }
      
      p {
        font-size: 16px;
        line-height: 1.5;
      }
      
      ul {
        margin: 0;
        padding: 0;
        list-style: none;
      }
      
      li {
        margin-bottom: 10px;
      }
      
      a {
        color: #333;
        text-decoration: none;
        font-weight: bold;
      }
      
      a:hover {
        text-decoration: underline;
      }
      
      footer {
  background-color: #007bff;
  color: #fff;
  padding: 1rem;
  text-align: center;
  position: absolute;
  left: 0;
  bottom: -110px;
  width: 100%;
  text-align: center;
  padding: 20px 0;
  margin: 0;
  font-size: 1rem;
}
a:link {
      text-decoration: none;
      color: black;
}

a:visited {
      text-decoration: none;
      color: black;
}

a:hover {
    color: black;
      text-decoration: none;
}

a:active {
    color: black;
      text-decoration: none;
}

ul{
	display: flex;
	height: 30vh;
	margin: auto;
	justify-content: space-between;
	text-align: center;
}
li {
	padding: 1rem 2rem 1.15rem;
  text-transform: uppercase;
  cursor: pointer;
  color: black;
	min-width: 80px;
	margin: auto;
}

li:hover {
  background-image: url('https://scottyzen.sirv.com/Images/v/button.png');
  background-size: 100% 100%;
  color: #27262c;
  animation: spring 300ms ease-out;
  text-shadow: 0 -1px 0 #ef816c;
	font-weight: bold;
}
li:active {
  transform: translateY(4px);
}
    </style>
  </head>
  <body>
    <header>
      <h1>Въведение в PHP– какво трябва да знем за този програмен език</h1>
    </header>
    
    <main>
      <section>
        <p>За да можете да разберете всичко в този курс, са ви необходими поне базови познания по:
     HTML, CSS и JavaScript. Ако все още не сте или искате да преминете първо тях, можете да ги прегледате в предишните уроци.
            </p>
            <br>
            <p>
            Какво е PHP?
PHP е съкращение от PHP Hypertext Preprocessor, и е широко употребяван език за програмиране.
 Той е безплатен и свободен за употреба и инсталация. PHP скриптовете се изпълняват на сървъра, като генерират чист HTML код.
  В PHP файловете, може да се съдържа HTML, CSS или JavaScript код, като разширението на тези файлове е .php. 
            </p>
            <br>
            <p>
            Какво можем да правим с PHP?
Можем динамично да генерираме съдържание.
Можем да отваряме, затваряме, четем и пишем във файлове на сървъра.
Можем да събираме информацията от HTML формуляри.
Можем да контролираме достъпа на потребителите и да модифицираме бази данни.
            </p>
            <br>
            <p>
            Как да инсталираме PHP?
Има няколко различни начина да „подкарате“ PHP. Вече повечето системи го предоставят по подразбиране. 
Препоръчваме ви, за да спестите време, да инсталирате MAMP, XAMP, WAMP или друг еквивалент. По този начин, 
получавате всичко необходимо, чрез една инсталация (PHP, Apache, PhpMyAdmin) и така няма да има нужда да инсталирате нищо друго.
 Важно: нужен ви е уеб сървър за да може да зареждате PHP скриптове.  
            </p>
      </section>
    </main>
    <nav>
    <ul>
            <li><a href="index.php">Начало</a></li>
			<li><a href="lessons.php">Уроци</a></li>
			<li><a href="lesson2.php">Следващ Урок</a></li>
			<li><a href="lesson1.php">Предишен Урок</a></li>
</ul>
    </nav>
    <footer>
    <p>&copy; 2023 Система за самообучение по PHP</p>
    </footer>
  </body>
</html>