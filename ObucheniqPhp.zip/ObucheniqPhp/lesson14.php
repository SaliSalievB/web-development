<!DOCTYPE html>
<html>
  <head>
    <title>Lesson Page</title>
    <style>
      body {
        font-family: Arial, sans-serif;
        background-color: #f0f0f0;
        margin: 0;
        padding: 0;
      }
      
      header {
        background-color: #007bff;
        color: #fff;
        padding: 20px;
        text-align: center;
      }
      
      h1 {
        
        margin: 0;
        font-size: 36px;
      }
      
      main {
        margin: 20px;
      }
      
      section {
        background-color: #fff;
        border: 1px solid #ccc;
        border-radius: 5px;
        padding: 10px;
        margin-bottom: 20px;
      }
      
      h2 {
        font-size: 24px;
        margin-top: 0;
      }
      
      p {
        font-size: 16px;
        line-height: 1.5;
      }
      
      ul {
        margin: 0;
        padding: 0;
        list-style: none;
      }
      
      li {
        margin-bottom: 10px;
      }
      
      a {
        color: #333;
        text-decoration: none;
        font-weight: bold;
      }
      
      a:hover {
        text-decoration: underline;
      }
      
      footer {
  background-color: #007bff;
  color: #fff;
  padding: 1rem;
  text-align: center;
  position: absolute;
  left: 0;
  bottom: -450px;
  width: 100%;
  text-align: center;
  padding: 20px 0;
  margin: 0;
  font-size: 1rem;
}
a:link {
      text-decoration: none;
      color: black;
}

a:visited {
      text-decoration: none;
      color: black;
}

a:hover {
    color: black;
      text-decoration: none;
}

a:active {
    color: black;
      text-decoration: none;
}

ul{
	display: flex;
	height: 30vh;
	margin: auto;
	justify-content: space-between;
	text-align: center;
}
li {
	padding: 1rem 2rem 1.15rem;
  text-transform: uppercase;
  cursor: pointer;
  color: black;
	min-width: 80px;
	margin: auto;
}

li:hover {
  background-image: url('https://scottyzen.sirv.com/Images/v/button.png');
  background-size: 100% 100%;
  color: #27262c;
  animation: spring 300ms ease-out;
  text-shadow: 0 -1px 0 #ef816c;
	font-weight: bold;
}
li:active {
  transform: translateY(4px);
}
    </style>
  </head>
  <body>
    <header>
      <h1>Регулярни израз в PHP</h1>
    </header>
    
    <main>
      <section>
      <p>
      Регулярните изрази са мощен инструмент за търсене и манипулиране на текст в PHP. <br>
      Те представляват последователности от символи, които описват шаблон от символи, който се търси в низове.<br>
       Регулярните изрази могат да бъдат използвани за проверка на входни данни,
        извличане на информация от текстови файлове и други манипулации с текст.<br>

В PHP регулярните изрази се използват с функциите за работа с регулярни изрази 
- preg_match(), preg_match_all(), preg_replace() и други.<br>
 Тези функции приемат регулярен израз и низ, с който да се сравни регулярния израз.<br>

В следващите редове ще разгледаме някои от най-често използваните символи и оператори в регулярни изрази в PHP:<br>

Символът "." (точка) съответства на всеки един символ.<br>
Символът "^" съответства на началото на низа.<br>
Символът "$" съответства на края на низа.<br>
Символът "*" съответства на нула или повече повторения на предходния символ или група.<br>
Символът "+" съответства на едно или повече повторения на предходния символ или група.<br>
Символът "?" съответства на нула или едно повторение на предходния символ или група.<br>
Групите се ограждат с () и могат да се използват за извличане на информация от низа или за по-сложни проверки.<br>
Класовете от символи се ограждат с [] и съответстват на един от символите в скобите.<br>
Нека символите, които не искаме да съвпадат, могат да се поставят в [] със знака "^" преди тях.<br>
Примери:<br>

Регулярният израз "/\d{3}-\d{2}-\d{4}/" съответства на социални сигурностни номера във формат 123-45-6789.<br>
Регулярният израз "/^[A-Z]/" съответства на низове, които започват с главна буква.<br>
Регулярният израз "/.php$/" съответства на низове, които завършват на ".php".<br>
Регулярният израз "/\w+@\w+.\w+/" съответства на електронни пощи във формат name@example.com.<br>
Регулярният израз "/[aeiou]/" съответства на низове, които съдържат поне една от гласните букви a, e, i, o или u.<br>
Регулярният израз "/^[^0-9]/" съответства на низове, които не започват с цифра.<br>
Групите в регулярни изрази могат да се използват за извличане на информация от текстови низове. <br>Например,
 ако искаме да извлечем име и фамилия от низ, който съдържа име,
  фамилия и телефонен номер във формат "John Doe (555) 123-4567", можем да използваме регулярния израз
   "/([A-Za-z]+) ([A-Za-z]+) <br>
(\d3)\s?(\d{3})-(\d{4})/".<br> Този израз ще извлече името, фамилията и телефонния номер на човека.<br>

Регулярните изрази могат да бъдат сложни и мощни инструменти за работа с текст в PHP.<br>
 Но те могат да бъдат и трудни за разбиране и отстраняване на грешки, 
 затова е важно да се запознаете с тяхното използване и да използвате документацията и онлайн ресурсите,
  за да ги използвате правилно.<br>
 която може да ни помогне да поддържаме кода ни по-надежден и да предотвратим непредвидими проблеми.
    </p>
      </section>
    </main>
    <nav>
    <ul>
            <li><a href="index.php">Начало</a></li>
			<li><a href="lessons.php">Уроци</a></li>
			<li><a href="lesson15.php">Следващ Урок</a></li>
			<li><a href="lesson13.php">Предишен Урок</a></li>
</ul>
    </nav>
    <footer>
    <p>&copy; 2023 Система за самообучение по PHP</p>
    </footer>
  </body>
</html> 