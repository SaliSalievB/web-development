<!DOCTYPE html>
<html>
  <head>
    <title>Lesson Page</title>
    <style>
      body {
        font-family: Arial, sans-serif;
        background-color: #f0f0f0;
        margin: 0;
        padding: 0;
      }
      
      header {
        background-color: #007bff;
        color: #fff;
        padding: 20px;
        text-align: center;
      }
      
      h1 {
        
        margin: 0;
        font-size: 36px;
      }
      
      main {
        margin: 20px;
      }
      
      section {
        background-color: #fff;
        border: 1px solid #ccc;
        border-radius: 5px;
        padding: 10px;
        margin-bottom: 20px;
      }
      
      h2 {
        font-size: 24px;
        margin-top: 0;
      }
      
      p {
        font-size: 16px;
        line-height: 1.5;
      }
      
      ul {
        margin: 0;
        padding: 0;
        list-style: none;
      }
      
      li {
        margin-bottom: 10px;
      }
      
      a {
        color: #333;
        text-decoration: none;
        font-weight: bold;
      }
      
      a:hover {
        text-decoration: underline;
      }
      
      footer {
  background-color: #007bff;
  color: #fff;
  padding: 1rem;
  text-align: center;
  position: absolute;
  left: 0;
  bottom: -100px;
  width: 100%;
  text-align: center;
  padding: 20px 0;
  margin: 0;
  font-size: 1rem;
}
a:link {
      text-decoration: none;
      color: black;
}

a:visited {
      text-decoration: none;
      color: black;
}

a:hover {
    color: black;
      text-decoration: none;
}

a:active {
    color: black;
      text-decoration: none;
}

ul{
	display: flex;
	height: 30vh;
	margin: auto;
	justify-content: space-between;
	text-align: center;
}
li {
	padding: 1rem 2rem 1.15rem;
  text-transform: uppercase;
  cursor: pointer;
  color: black;
	min-width: 80px;
	margin: auto;
}

li:hover {
  background-image: url('https://scottyzen.sirv.com/Images/v/button.png');
  background-size: 100% 100%;
  color: #27262c;
  animation: spring 300ms ease-out;
  text-shadow: 0 -1px 0 #ef816c;
	font-weight: bold;
}
li:active {
  transform: translateY(4px);
}
    </style>
  </head>
  <body>
    <header>
      <h1>XML и PHP</h1>
    </header>
    
    <main>
      <section>
      <p>
XML е език за маркиране на данни, който позволява на потребителите да дефинират свои собствени етикети за описание на информацията. <br>
       Той е основен елемент в много приложения, където данните се обменят между различни системи и платформи.<br>

PHP поддържа работа с XML данни чрез множество библиотеки и функции, като най-известната от тях е SimpleXML.<br>

SimpleXML е библиотека за PHP, която позволява лесна работа с XML данни.<br>
 Тя предоставя обектно-ориентиран подход за работа с XML документи.<br>
  SimpleXML може да зарежда XML данни от файлове, низове или URL адреси и да ги обработва като обекти.<br>

Ето пример за зареждане на XML документ и достъп до неговите елементи с помощта на SimpleXML:<br>


$xml = simplexml_load_file("example.xml");<br>

echo $xml->book[0]->title;<br>
echo $xml->book[0]->author;<br>
echo $xml->book[1]->title;<br>
echo $xml->book[1]->author;<br>
В горния пример зареждаме XML документа "example.xml" <br>
и достъпваме неговите елементи с помощта на обектно-ориентирания подход на SimpleXML.<br>

PHP предоставя множество други функции и библиотеки за работа с XML, като DOMDocument, XML Parser и XMLReader.<br>
 В зависимост от конкретната задача, може да е по-подходящо да използвате една от тези алтернативи вместо SimpleXML.
    </p>
      </section>
    </main>
    <nav>
    <ul>
            <li><a href="index.php">Начало</a></li>
			<li><a href="lessons.php">Уроци</a></li>
			<li><a href="lesson18.php">Упражнение 3</a></li>
			<li><a href="lesson16.php">Предишен Урок</a></li>
</ul>
    </nav>
    <footer>
    <p>&copy; 2023 Система за самообучение по PHP</p>
    </footer>
  </body>
</html> 