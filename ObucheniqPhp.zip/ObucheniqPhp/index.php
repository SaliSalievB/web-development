<!DOCTYPE html>
<html>
<head>
	<title>Система за самообучение по PHP</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
 
/* Размер на шрифтовете */
html {
  font-size: 16px;
}

@media (max-width: 576px) {
  html {
    font-size: 14px;
  }
}

@media (max-width: 320px) {
  html {
    font-size: 12px;
  }
}

/* Главна секция */
main {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
  gap: 1rem;
  padding: 2rem;
}
/* Футър */
footer {
  background-color: #007bff;
  color: #fff;
  padding: 1rem;
  text-align: center;
  position: absolute;
  left: 0;
  bottom: 0px;
  width: 100%;
  text-align: center;
  padding: 20px 0;
  margin: 0;
  font-size: 1rem;
}

body {
  background-color: whitesmoke;
  font-family: Arial, Helvetica, sans-serif;
  font-size: 18px;
}
* {
	margin: 0;
	padding: 0;
	list-style-type: none;
}

ul{
	display: flex;
	height: 30vh;
	margin: auto;
	justify-content: space-between;
	text-align: center;
}
li {
	padding: 1rem 2rem 1.15rem;
  text-transform: uppercase;
  cursor: pointer;
  color: black;
	min-width: 80px;
	margin: auto;
}

li:hover {
  background-image: url('https://scottyzen.sirv.com/Images/v/button.png');
  background-size: 100% 100%;
  color: #27262c;
  animation: spring 300ms ease-out;
  text-shadow: 0 -1px 0 #ef816c;
	font-weight: bold;
}
li:active {
  transform: translateY(4px);
}

@keyframes spring {
  15% {
    -webkit-transform-origin: center center;
    -webkit-transform: scale(1.2, 1.1);
  }
  40% {
    -webkit-transform-origin: center center;
    -webkit-transform: scale(0.95, 0.95);
  }
  75% {
    -webkit-transform-origin: center center;
    -webkit-transform: scale(1.05, 1);
  }
  100% {
    -webkit-transform-origin: center center;
    -webkit-transform: scale(1, 1);
  }
}
header .container{
    text-align: center;
}
 a:link {
      text-decoration: none;
      color: black;
}

a:visited {
      text-decoration: none;
      color: black;
}

a:hover {
    color: black;
      text-decoration: none;
}

a:active {
    color: black;
      text-decoration: none;
}
    </style>
</head>
<body>
    <br>
	<header>
		<div class="container">

			<h1>Система за самообучение по PHP</h1>
		</div>
	
<nav>
<ul>
      <li><a href="index.php">Начало</a></li>
			<li><a href="lessons.php">Уроци</a></li>
			<li><a href="lesson6.php">Упражнениe 1</a></li>
			<li><a href="lesson25.php">Тест</a></li>
</ul>
</nav>
    </header>
	<main>
		<div class="text">
			<h2>Добре дошли в системата за самообучение по PHP!</h2>
            <br>
			<p>PHP е един от най-популярните езици за програмиране на уеб сайтове и приложения. С тази система за самообучение вие ще можете да научите основните аспекти на PHP и да започнете да създавате свои уеб проекти.</p>
			<p>Системата включва 20 урока, 5 упражнения и 1 тест, които ще ви помогнат да се запознаете със синтаксиса на PHP, да научите как да работите с бази данни и да разберете как да създавате динамични уеб страници.</p>
			<p>Започнете с първия урок и продължете напред, докато не завършите цялата система за самообучение. Пожелаваме ви приятно учене!</p>
			<br>
            <a href="lessons.php" class="btn"><b>Започни уроците</b></a>
		</div>
	</main>
    <footer>
		<div class="container">
			<p>&copy; 2023 Система за самообучение по PHP</p>
		</div>
	</footer>
</body>
</html>
