<!DOCTYPE html>
<html>
  <head>
    <title>Lesson Page</title>
    <style>
      body {
        font-family: Arial, sans-serif;
        background-color: #f0f0f0;
        margin: 0;
        padding: 0;
      }
      
      header {
        background-color: #007bff;
        color: #fff;
        padding: 20px;
        text-align: center;
      }
      
      h1 {
        
        margin: 0;
        font-size: 36px;
      }
      
      main {
        margin: 20px;
      }
      
      section {
        background-color: #fff;
        border: 1px solid #ccc;
        border-radius: 5px;
        padding: 10px;
        margin-bottom: 20px;
      }
      
      h2 {
        font-size: 24px;
        margin-top: 0;
      }
      
      p {
        font-size: 16px;
        line-height: 1.5;
      }
      
      ul {
        margin: 0;
        padding: 0;
        list-style: none;
      }
      
      li {
        margin-bottom: 10px;
      }
      
      a {
        color: #333;
        text-decoration: none;
        font-weight: bold;
      }
      
      a:hover {
        text-decoration: underline;
      }
      
      footer {
  background-color: #007bff;
  color: #fff;
  padding: 1rem;
  text-align: center;
  position: absolute;
  left: 0;
  bottom: -200px;
  width: 100%;
  text-align: center;
  padding: 20px 0;
  margin: 0;
  font-size: 1rem;
}
a:link {
      text-decoration: none;
      color: black;
}

a:visited {
      text-decoration: none;
      color: black;
}

a:hover {
    color: black;
      text-decoration: none;
}

a:active {
    color: black;
      text-decoration: none;
}

ul{
	display: flex;
	height: 30vh;
	margin: auto;
	justify-content: space-between;
	text-align: center;
}
li {
	padding: 1rem 2rem 1.15rem;
  text-transform: uppercase;
  cursor: pointer;
  color: black;
	min-width: 80px;
	margin: auto;
}

li:hover {
  background-image: url('https://scottyzen.sirv.com/Images/v/button.png');
  background-size: 100% 100%;
  color: #27262c;
  animation: spring 300ms ease-out;
  text-shadow: 0 -1px 0 #ef816c;
	font-weight: bold;
}
li:active {
  transform: translateY(4px);
}
    </style>
  </head>
  <body>
    <header>
      <h1>Техники за отстраняване на грешки в PHP</h1>
    </header>
    
    <main>
      <section>
      <p>Отстраняването на грешки в PHP може да бъде трудно, особено ако програмата е голяма и сложна. <br>
         Ето някои техники за отстраняване на грешки в PHP:<br>

Използване на функцията error_reporting(): <br>
Тази функция позволява да се контролира кои грешки се докладват и как. <br>
Най-добрата практика е да се настрои PHP да докладва всички грешки.<br>

Използване на функцията ini_set():<br>
 Тази функция позволява на програмиста да промени някои от стандартните настройки на PHP.<br>
 Най-важното е да се настрои PHP да показва грешки, когато те се появят.<br>

Използване на функцията debug_backtrace(): <br>
Тази функция връща масив от данни,
 който съдържа информация за мястото на извикване на функциите в стека на извикването. <br>
 Това може да помогне при откриването на грешки, като например грешки в параметрите на функциите.<br>

Използване на функцията var_dump(): Тази функция извежда информация за типа и стойността на променливата. <br>
Това може да помогне при откриването на грешки, като например грешки в типовете на променливите.<br>

Използване на инструменти за отстраняване на грешки: <br>
Съществуват много инструменти за отстраняване на грешки в PHP, като например Xdebug и PHP Debug Bar. <br>
Tези инструменти могат да помогнат при откриването и отстраняването на грешки в програмите.<br>

Постоянно тестване на програмите: Най-добрата практика е да се тестват програмите постоянно и систематично.<br>
 Това може да помогне при откриването на грешки преди да станат проблеми в продукцията.<br>

Използване на логове: Съществуват различни видове логове, като например error log и access log.<br>
 Те могат да помогнат при откриването на грешки, като например неправилна употреба на функции или грешки в сървъра.
    </p>
      </section>
    </main>
    <nav>
    <ul>
            <li><a href="index.php">Начало</a></li>
			<li><a href="lessons.php">Уроци</a></li>
			<li><a href="lesson22.php">Следващ Урок</a></li>
			<li><a href="lesson20.php">Предишен Урок</a></li>
</ul>
    </nav>
    <footer>
    <p>&copy; 2023 Система за самообучение по PHP</p>
    </footer>
  </body>
</html> 