<!DOCTYPE html>
<html>
<head>
	<title> Уроци </title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
    :root {
  --primary-color: #212121;
  --background-color: #111;
  --font: sans-serif;
}

* {
  margin: 0;
  padding: 0;
}

body {
  background-color: lightskyblue;
  font-family: var(--font);
  display: flex;
  justify-content: center;
}

/* Timeline Container */
.timeline {
  background-color: lightskyblue;
  padding: 30px;
  margin: 20px auto;
  padding: 20px;
  display: inline-block;
}
/* Card container */
.card {
  position: relative;
  max-width: 400px;
}

/* setting padding based on even or odd */
.card:nth-child(odd) {
  padding: 30px 0 30px 30px;
}
.card:nth-child(even) {
  padding: 30px 30px 30px 0;
}
/* Global ::before */
.card::before {
  content: "";
  position: absolute;
  width: 50%;
  border: solid orangered;
}

/* Setting the border of top, bottom, left */
.card:nth-child(odd)::before {
  left: 0px;
  top: -4.5px;
  bottom: -4.5px;
  border-width: 5px 0 5px 5px;
  border-radius: 50px 0 0 50px;
}

/* Setting the border of top, bottom, right */
.card:nth-child(even)::before {
  right: 0;
  top: 0;
  bottom: 0;
  border-width: 5px 5px 5px 0;
  border-radius: 0 50px 50px 0;
}

/* Removing the border if it is the first card */
.card:first-child::before {
  border-top: 0;
  border-top-left-radius: 0;
}

/* Removing the border if it is the last card  and it's odd */
.card:last-child:nth-child(odd)::before {
  border-bottom: 0;
  border-bottom-left-radius: 0;
}

/* Removing the border if it is the last card  and it's even */
.card:last-child:nth-child(even)::before {
  border-bottom: 0;
  border-bottom-right-radius: 0;
}

/* Information about the timeline */
.info {
  display: flex;
  flex-direction: column;
  background: #333;
  color: gray;
  border-radius: 10px;
  padding: 10px;
}

/* Title of the card */
.title {
  color: orangered;
  position: relative;
}

/* Timeline dot  */
.title::before {
  content: "";
  position: absolute;
  width: 10px;
  height: 10px;
  background: white;
  border-radius: 999px;
  border: 3px solid orangered;
}

/* text right if the card is even  */
.card:nth-child(even) > .info > .title {
  text-align: right;
}

/* setting dot to the left if the card is odd */
.card:nth-child(odd) > .info > .title::before {
  left: -45px;
}

/* setting dot to the right if the card is odd */
.card:nth-child(even) > .info > .title::before {
  right: -45px;
}
#content-container {
  float: right;
  width: 50%;
}
.lesson {
  display: none;
}

.lesson-title {
  font-size: 1.5rem;
  font-weight: bold;
}

.lesson-description {
  font-size: 1.2rem;
  margin-bottom: 1rem;
}

.lesson-objectives {
  margin-bottom: 1rem;
}

.lesson-content {
  margin-top: 1rem;
}
table{
  text-align: center;
  width: 50%
}
</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
</head>
<body>
<main>
<div class="timeline" >
  <div class="outer">
    <div class="card">
      <div class="info">
        <h3 class="title"><a href="lesson1.php">Урок 1</a></h3>
        <p>Въведение в PHP</p>
      </div>
    </div>
    <div class="card">
    <div class="info">
    <h3 class="title"><a href="lesson2.php"> Урок 2 </a></h3>
        <p>Променливи и типове данни в PHP</p>
      </div>
    </div>
    <div class="card">
    <div class="info">
    <h3 class="title"><a href="lesson3.php"> Урок 3 </a> </h3>
        <p>Условни оператори в PHP</p>
      </div>
    </div>
    <div class="card">
    <div class="info">
    <h3 class="title"><a href="lesson4.php"> Урок 4 </a></h3>
        <p>Цикли в PHP</p>
      </div>
    </div>
    <div class="card">
    <div class="info">
    <h3 class="title"><a href="lesson5.php"> Урок 5 </a> </h3>
        <p>Масиви в PHP</p>
      </div>
    </div>
    <div class="card">
    <div class="info">
    <h3 class="title"><a href="lesson6.php"> Упражнение 1 </a> </h3>
        <p></p>
      </div>
    </div>
    <div class="card">
      <div class="info">
      <h3 class="title"><a href="lesson7.php"> Урок 6  </a></h3>
        <p>Функции в PHP</p>
      </div>
    </div>
    <div class="card">
    <div class="info">
    <h3 class="title"><a href="lesson8.php"> Урок 7  </a></h3>
        <p>Формуляри в PHP</p>
      </div>
    </div>
    <div class="card">
    <div class="info">
    <h3 class="title"><a href="lesson9.php"> Урок 8 </a></h3>
        <p>Работа с файлове в PHP</p>
      </div>
    </div>
    <div class="card">
    <div class="info">
    <h3 class="title"><a href="lesson10.php"> Урок 9</a> </h3>
        <p>Бисквитки и сесии в PHP</p>
      </div>
    </div>
    <div class="card">
    <div class="info">
    <h3 class="title"><a href="lesson11.php"> Урок 10 </a></h3>
        <p>Обектно-ориентирано програмиране в PHP</p>
      </div>
    </div>
    <div class="card">
    <div class="info">
    <h3 class="title"><a href="lesson12.php"> Упражнение 2</a></h3>
        <p></p>
      </div>
    </div>
    <div class="card">
      <div class="info">
      <h3 class="title"><a href="lesson13.php"> Урок 11</a> </h3>
        <p>Обработка на грешки в PHP</p>
      </div>
    </div>
    <div class="card">
    <div class="info">
    <h3 class="title"><a href="lesson14.php"> Урок 12</a></h3>
        <p>Регулярни изрази в PHP</p>
      </div>
    </div>
    <div class="card">
    <div class="info">
    <h3 class="title"><a href="lesson15.php"> Урок 13</a> </h3>
        <p>Свързване към база данни в PHP</p>
      </div>
    </div>
    <div class="card">
    <div class="info">
    <h3 class="title"><a href="lesson16.php"> Урок 14 </a></h3>
        <p>Изпращане на имейли с PHP</p>
      </div>
    </div>
    <div class="card">
    <div class="info">
    <h3 class="title"><a href="lesson17.php"> Урок 15 </a></h3>
        <p>XML и PHP</p>
      </div>
    </div>
    <div class="card">
    <div class="info">
    <h3 class="title"><a href="lesson18.php"> Упражнение 3</a></h3>
        <p></p>
      </div>
    </div>
    <div class="card">
      <div class="info">
      <h3 class="title"><a href="lesson19.php"> Урок 16 </a></h3>
        <p>Обработка на изображения в PHP</p>
      </div>
    </div>
    <div class="card">
    <div class="info">
    <h3 class="title"><a href="lesson20.php"> Урок 17 </a></h3>
        <p>Сигурност в PHP</p>
      </div>
    </div>
    <div class="card">
    <div class="info">
    <h3 class="title"><a href="lesson21.php"> Урок 18 </a></h3>
        <p>Техники за отстраняване на грешки в PHP</p>
      </div>
    </div>
    <div class="card">
    <div class="info">
    <h3 class="title"><a href="lesson22.php"> Урок 19</a> </h3>
        <p>Най-добри практики в разработката на PHP</p>
      </div>
    </div>
    <div class="card">
    <div class="info">
    <h3 class="title"><a href="lesson23.php"> Урок 20</a> </h3>
        <p>PHP Frameworks и CMS.</p>
      </div>
    </div>
    <div class="card">
    <div class="info">
    <h3 class="title"><a href="lesson24.php"> Упражнение 4 и 5</a></h3>
        <p></p>
      </div>
    </div>
    <div class="card">
    <div class="info">
    <h3 class="title"><a href="lesson25.php"> Тест</a></h3>
        <p>Тест включващ всичко изучено в курса</p>
      </div>
    </div>
  </div>
</div>
  </div>
  </div>
</main>
</body>
</html>