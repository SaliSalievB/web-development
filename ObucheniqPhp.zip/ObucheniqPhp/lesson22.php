<!DOCTYPE html>
<html>
  <head>
    <title>Lesson Page</title>
    <style>
      body {
        font-family: Arial, sans-serif;
        background-color: #f0f0f0;
        margin: 0;
        padding: 0;
      }
      
      header {
        background-color: #007bff;
        color: #fff;
        padding: 20px;
        text-align: center;
      }
      
      h1 {
        
        margin: 0;
        font-size: 36px;
      }
      
      main {
        margin: 20px;
      }
      
      section {
        background-color: #fff;
        border: 1px solid #ccc;
        border-radius: 5px;
        padding: 10px;
        margin-bottom: 20px;
      }
      
      h2 {
        font-size: 24px;
        margin-top: 0;
      }
      
      p {
        font-size: 16px;
        line-height: 1.5;
      }
      
      ul {
        margin: 0;
        padding: 0;
        list-style: none;
      }
      
      li {
        margin-bottom: 10px;
      }
      
      a {
        color: #333;
        text-decoration: none;
        font-weight: bold;
      }
      
      a:hover {
        text-decoration: underline;
      }
      
      footer {
  background-color: #007bff;
  color: #fff;
  padding: 1rem;
  text-align: center;
  position: absolute;
  left: 0;
  bottom: -600px;
  width: 100%;
  text-align: center;
  padding: 20px 0;
  margin: 0;
  font-size: 1rem;
}
a:link {
      text-decoration: none;
      color: black;
}

a:visited {
      text-decoration: none;
      color: black;
}

a:hover {
    color: black;
      text-decoration: none;
}

a:active {
    color: black;
      text-decoration: none;
}

ul{
	display: flex;
	height: 30vh;
	margin: auto;
	justify-content: space-between;
	text-align: center;
}
li {
	padding: 1rem 2rem 1.15rem;
  text-transform: uppercase;
  cursor: pointer;
  color: black;
	min-width: 80px;
	margin: auto;
}

li:hover {
  background-image: url('https://scottyzen.sirv.com/Images/v/button.png');
  background-size: 100% 100%;
  color: #27262c;
  animation: spring 300ms ease-out;
  text-shadow: 0 -1px 0 #ef816c;
	font-weight: bold;
}
li:active {
  transform: translateY(4px);
}
    </style>
  </head>
  <body>
    <header>
      <h1>най-добрите практики в разработката на PHP</h1>
    </header>
    
    <main>
      <section>
      <p>Ето няколко от най-добрите практики в разработката на PHP: <br>

Използвайте обектно-ориентиран подход -<br>
 Обектно-ориентираното програмиране (ООП) е един от най-ефективните начини за разработка на PHP приложения. <br>
 То позволява създаването на по-структурирани, поддържаеми и разширяеми приложения.<br>

Използвайте MVC архитектура - <br>
Модел-изглед-контролер (MVC) е архитектурен шаблон за проектиране на приложения,
 който разделя приложението на три основни компонента: модел, който управлява данните и бизнес логиката, изглед, 
 който представя данните на потребителите и контролер, който свързва модела и изгледа.<br>

Пишете чист код -<br>
 Чистият код е лесен за разбиране, поддържане и разширяване.<br>
 Затова е важно да пишете чист код, който е лесен за четене и разбиране. <br>
 Прилагането на правилата за чист код на Robert C. Martin е добро начало.<br>

Използвайте подготвени заявки -<br>
 Подготвените заявки са по-безопасни от обикновените заявки и могат да предотвратят SQL инжекции.<br>

Валидирайте входните данни - <br>
Входните данни трябва да бъдат валидирани, преди да бъдат използвани в приложението.<br>
 Това може да предотврати много видове атаки като например SQL инжекции, XSS атаки и други.<br>

Използвайте вградените функции на PHP - <br>
Вградените функции на PHP могат да Ви спестят много време и усилия. <br>
PHP предлага много вградени функции за работа с масиви, низове, дати, файлове и други.<br>

Използвайте библиотеки и фреймуърки -<br>
 Библиотеките и фреймуърките могат да Ви спестят много време и усилия при разработката на приложения. <br>
 Например, Laravel и Symfony са добре известни фреймуърки за PHP.<br>

Използвайте автолоудър -<br>
 Автолоудът е функционалност на PHP, която автоматично зарежда класовете и техните зависимости в приложението.<br>
  Това Ви спестява време и усилия при зареждането на класовете във Вашето приложение.<br>

 Създавайте ефективни заявки към базата данни - <br>
 Винаги е важно да създавате ефективни заявки към базата данни, като използвате индекси и оптимизирате заявките.<br>
  Това ще Ви помогне да подобрите бързодействието на Вашето приложение.<br>

Използвайте кеширане - <br>
Кеширането е механизъм, който може да подобри бързодействието на Вашето приложение, 
като запазва временно данните в паметта. Това Ви спестява време и усилия при извличането на данни от базата данни.<br>

Тествайте приложението си - <br>
Тестването е важна част от разработката на PHP приложения. <br>
То Ви позволява да намерите и отстраните грешки във Вашето приложение преди да бъде пуснато в продукция. <br>
PHPUnit е един от най-популярните инструменти за тестване в PHP.<br>

Използвайте инструменти за управление на кода - <br>
Инструментите за управление на кода като Git и SVN Ви позволяват да следите промените във Вашия код и да сътрудничите 
с други разработчици по проекта. <br>
Това е важно за поддръжката и разширяването на приложението Ви в бъдеще.
    </p>
      </section>
    </main>
    <nav>
    <ul>
            <li><a href="index.php">Начало</a></li>
			<li><a href="lessons.php">Уроци</a></li>
			<li><a href="lesson23.php">Следващ Урок</a></li>
			<li><a href="lesson21.php">Предишен Урок</a></li>
</ul>
    </nav>
    <footer>
    <p>&copy; 2023 Система за самообучение по PHP</p>
    </footer>
  </body>
</html> 