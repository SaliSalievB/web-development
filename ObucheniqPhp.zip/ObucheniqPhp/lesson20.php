<!DOCTYPE html>
<html>
  <head>
    <title>Lesson Page</title>
    <style>
      body {
        font-family: Arial, sans-serif;
        background-color: #f0f0f0;
        margin: 0;
        padding: 0;
      }
      
      header {
        background-color: #007bff;
        color: #fff;
        padding: 20px;
        text-align: center;
      }
      
      h1 {
        
        margin: 0;
        font-size: 36px;
      }
      
      main {
        margin: 20px;
      }
      
      section {
        background-color: #fff;
        border: 1px solid #ccc;
        border-radius: 5px;
        padding: 10px;
        margin-bottom: 20px;
      }
      
      h2 {
        font-size: 24px;
        margin-top: 0;
      }
      
      p {
        font-size: 16px;
        line-height: 1.5;
      }
      
      ul {
        margin: 0;
        padding: 0;
        list-style: none;
      }
      
      li {
        margin-bottom: 10px;
      }
      
      a {
        color: #333;
        text-decoration: none;
        font-weight: bold;
      }
      
      a:hover {
        text-decoration: underline;
      }
      
      footer {
  background-color: #007bff;
  color: #fff;
  padding: 1rem;
  text-align: center;
  position: absolute;
  left: 0;
  bottom: -270px;
  width: 100%;
  text-align: center;
  padding: 20px 0;
  margin: 0;
  font-size: 1rem;
}
a:link {
      text-decoration: none;
      color: black;
}

a:visited {
      text-decoration: none;
      color: black;
}

a:hover {
    color: black;
      text-decoration: none;
}

a:active {
    color: black;
      text-decoration: none;
}

ul{
	display: flex;
	height: 30vh;
	margin: auto;
	justify-content: space-between;
	text-align: center;
}
li {
	padding: 1rem 2rem 1.15rem;
  text-transform: uppercase;
  cursor: pointer;
  color: black;
	min-width: 80px;
	margin: auto;
}

li:hover {
  background-image: url('https://scottyzen.sirv.com/Images/v/button.png');
  background-size: 100% 100%;
  color: #27262c;
  animation: spring 300ms ease-out;
  text-shadow: 0 -1px 0 #ef816c;
	font-weight: bold;
}
li:active {
  transform: translateY(4px);
}
    </style>
  </head>
  <body>
    <header>
      <h1>Сигурност в PHP</h1>
    </header>
    
    <main>
      <section>
      <p>Сигурността в PHP е много важна, тъй като PHP е много широко използван език за уеб програмиране и 
         е изложен на много видове атаки. <br>
        Ето някои от най-важните мерки за сигурност в PHP:<br>

Валидация на данни: Това е процесът на проверка на входните данни, преди да бъдат използвани в програмата.<br>
 Най-честите видове валидация в PHP включват проверка за дължина на низа,
  проверка за числа и проверка за коректност на формат на електронната поща.<br>
   Правилната валидация на данни може да предотврати много видове атаки като например SQL инжекции, XSS атаки и много други.<br>

Защита на пароли: Паролите са много важни за сигурността на уеб приложенията, 
затова е важно да се използват силни пароли и да се съхраняват в хеширан вид. <br>
PHP предлага много функции за хеширане на пароли, като password_hash() и password_verify().<br>

Използване на подготвени заявки:<br>
 Подготвените заявки са заявки, които се компилират предварително и се изпълняват многократно с различни параметри.<br>
  Това може да предотврати SQL инжекции, като се избегнат проблеми с входните данни.<br>

Избягване на eval(): <br>
Функцията eval() в PHP изпълнява произволен PHP код и може да бъде опасна, ако се използва с неконтролирани данни.<br>
 Затова е по-добре да се използва други функции, като например call_user_func().<br>

Използване на HTTPS: HTTPS е протокол за сигурна комуникация между клиента и сървъра. <br>
Той криптира данните, изпратени между тях, като например потребителски имена и пароли,
 и предотвратява наблюдението на данните от трети страни.<br>

Обработка на грешки: Грешките в PHP могат да доведат до уязвимости в уеб приложенията. <br>
Затова е важно да се обработват грешките правилно и да се използва строг режим на PHP, 
който може да предотврати много от тези грешки.<br>

Съхранение на данни: Когато се съхраняват данни, е важно да се използва сигурно място, 
като например криптирани файлове или сигурни бази данни. <br>
Това може да предотврати достъпа до чувствителна информация от злонамерени потребители.<br>

Обновяване на софтуера: PHP и други софтуерни приложения трябва да бъдат редовно обновявани,
 за да се предотвратят нови видове атаки.<br>
 Това може да включва обновяване на PHP, уеб сървърни програми и други приложения, които използват PHP.<br>

Създаване на правилна логика на приложението:<br>
 Създаването на правилна логика на приложението е много важно за сигурността на PHP. <br>
Това може да включва правилната валидация на данни,
 защита на пароли, предотвратяване на SQL инжекции и други мерки за сигурност.<br>
 Това може да помогне за предотвратяване на нежелани атаки на уеб приложението.
    </p>
      </section>
    </main>
    <nav>
    <ul>
            <li><a href="index.php">Начало</a></li>
			<li><a href="lessons.php">Уроци</a></li>
			<li><a href="lesson21.php">Следващ Урок</a></li>
			<li><a href="lesson19.php">Предишен Урок</a></li>
</ul>
    </nav>
    <footer>
    <p>&copy; 2023 Система за самообучение по PHP</p>
    </footer>
  </body>
</html> 