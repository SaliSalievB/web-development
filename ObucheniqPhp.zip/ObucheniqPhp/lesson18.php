<!DOCTYPE html>
<html>
  <head>
    <title>Lesson Page</title>
    <style>
      body {
        font-family: Arial, sans-serif;
        background-color: #f0f0f0;
        margin: 0;
        padding: 0;
      }
      
      header {
        background-color: #007bff;
        color: #fff;
        padding: 20px;
        text-align: center;
      }
      
      h1 {
        
        margin: 0;
        font-size: 36px;
      }
      
      main {
        margin: 20px;
      }
      
      section {
        background-color: #fff;
        border: 1px solid #ccc;
        border-radius: 5px;
        padding: 10px;
        margin-bottom: 20px;
      }
      
      h2 {
        font-size: 24px;
        margin-top: 0;
      }
      
      p {
        font-size: 16px;
        line-height: 1.5;
      }
      
      ul {
        margin: 0;
        padding: 0;
        list-style: none;
      }
      
      li {
        margin-bottom: 10px;
      }
      
      a {
        color: #333;
        text-decoration: none;
        font-weight: bold;
      }
      
      a:hover {
        text-decoration: underline;
      }
      
      footer {
  background-color: #007bff;
  color: #fff;
  padding: 1rem;
  text-align: center;
  position: absolute;
  left: 0;
  bottom: -1100px;
  width: 100%;
  text-align: center;
  padding: 20px 0;
  margin: 0;
  font-size: 1rem;
}
a:link {
      text-decoration: none;
      color: black;
}

a:visited {
      text-decoration: none;
      color: black;
}

a:hover {
    color: black;
      text-decoration: none;
}

a:active {
    color: black;
      text-decoration: none;
}

ul{
	display: flex;
	height: 30vh;
	margin: auto;
	justify-content: space-between;
	text-align: center;
}
li {
	padding: 1rem 2rem 1.15rem;
  text-transform: uppercase;
  cursor: pointer;
  color: black;
	min-width: 80px;
	margin: auto;
}

li:hover {
  background-image: url('https://scottyzen.sirv.com/Images/v/button.png');
  background-size: 100% 100%;
  color: #27262c;
  animation: spring 300ms ease-out;
  text-shadow: 0 -1px 0 #ef816c;
	font-weight: bold;
}
li:active {
  transform: translateY(4px);
}
#answer{
    display: none;
}
    </style>
  </head>
  <body>
    <header>
      <h1>Задача за упражнение</h1>
    </header>
    
    <main>
      <section>
      <p>Да се направи уеб форма за регистрация на потребители,
        която ще записва данните в база данни и ще изпраща потвърждение на имейла на потребителя с използване на PHP и XML. <br>
        Формата трябва да съдържа полета за име, фамилия, имейл, парола и потвърждение на паролата.<br>
         След като потребителят попълни формата и я изпрати, данните трябва да бъдат записани в базата данни.<br>
          След това трябва да се генерира XML файл с информацията за потребителя и да се изпрати имейл на потребителя с
           линк за потвърждение на регистрацията.<br>
           
<h4>Когато сте готови или искате да видите правилния отговор натиснете бутона доло</h4>
<Button type="button" id="show">Клик</Button><br>
<div id="answer">
CREATE TABLE users (<br>
    id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,<br>
    firstname VARCHAR(30) NOT NULL,<br>
    lastname VARCHAR(30) NOT NULL,<br>
    email VARCHAR(50) NOT NULL,<br>
    password VARCHAR(255) NOT NULL,<br>
    registration_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP<br>
)
<br><br><br>
<'!DOCTYPE html><br>
<'html><br>
<'head><br>
    <'title>Регистрация на потребители<'/title><br>
<'/head><br>
<'body><br>
    <'h2>Регистрация на потребители<'/h2><br>
    <'form method="POST" action="<'?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>"><br>
        <'label>Име:<'/label><br>
        <'input type="text" name="firstname" required><'br><'br><br>
        <'label>Фамилия:<'/label><br>
        <'input type="text" name="lastname" required><'br><'br><br>
        <'label>Имейл:<'/label><br>
        <'input type="email" name="email" required><'br><'br><br>
        <'label>Парола:<'/label><br>
        <'input type="password" name="password" required><'br><'br><br>
        <'label>Потвърждение на паролата:<'/label><br>
        <'input type="password" name="confirm_password" required><'br><'br><br>
        <'input type="submit" name="submit" value="Регистрирай"><br>
    <'/'form><br>
    <'?php<br>
        if ($_SERVER["REQUESTED_METHOD"] == "POST") {<br>
// Свързване към базата данни<br>
$servername = "localhost";<br>
$username = "username";<br>
$password = "password";<br>
$dbname = "myDB";<br>
conn = mysqli_connect($servername, $username, $password, $dbname);<br>

        // Проверка за успешно свързване към базата данни<br>
        if (!$conn) {<br>
            die("Connection failed: " . mysqli_connect_error());<br>
        }<br>

        // Създаване на променливи за данните на потребителя<br>
        $firstname = $_POST["firstname"];<br>
        $lastname = $_POST["lastname"];<br>
        $email = $_POST["email"];<br>
        $password = $_POST["password"];<br>
        $confirm_password = $_POST["confirm_password"];<br>

        // Проверка за съвпадение на паролите<br>
        if ($password !== $confirm_password) {<br>
            echo "<'p>Паролите не съвпадат</'p>";<br>
        } else {<br>
            // Изпращане на заявката за добавяне на потребител в базата данни<br>
        $sql = "INSERT INTO users (firstname, lastname, email, password) VALUES ('$firstname', '$lastname', '$email', '$password')";<br>

            if (mysqli_query($conn, $sql)) {<br>
                echo "<'p>Потребител добавен успешно<'/p>";<br>
            } else {<br>
                echo "Error: " . $sql . "<'br>" . mysqli_error($conn);<br>
            }<br>
        }<br>

        // Затваряне на връзката с базата данниv
        mysqli_close($conn);<br>
    }<br>
?><br>
<'/body><br>
<'/html>
</div>
    </p>
      </section>
    </main>
    <nav>
    <ul>
            <li><a href="index.php">Начало</a></li>
			<li><a href="lessons.php">Уроци</a></li>
			<li><a href="lesson19.php">Следващ Урок</a></li>
			<li><a href="lesson17.php">Предишен Урок</a></li>
</ul>
    </nav>
    <footer>
    <p>&copy; 2023 Система за самообучение по PHP</p>
    </footer>
    <script>
        document.getElementById("show").addEventListener("click", function() {
  document.getElementById("answer").style.display = "block";
});

    </script>
  </body>
</html> 