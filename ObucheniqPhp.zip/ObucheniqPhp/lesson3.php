<!DOCTYPE html>
<html>
  <head>
    <title>Lesson Page</title>
    <style>
      body {
        font-family: Arial, sans-serif;
        background-color: #f0f0f0;
        margin: 0;
        padding: 0;
      }
      
      header {
        background-color: #007bff;
        color: #fff;
        padding: 20px;
        text-align: center;
      }
      
      h1 {
        
        margin: 0;
        font-size: 36px;
      }
      
      main {
        margin: 20px;
      }
      
      section {
        background-color: #fff;
        border: 1px solid #ccc;
        border-radius: 5px;
        padding: 10px;
        margin-bottom: 20px;
      }
      
      h2 {
        font-size: 24px;
        margin-top: 0;
      }
      
      p {
        font-size: 16px;
        line-height: 1.5;
      }
      
      ul {
        margin: 0;
        padding: 0;
        list-style: none;
      }
      
      li {
        margin-bottom: 10px;
      }
      
      a {
        color: #333;
        text-decoration: none;
        font-weight: bold;
      }
      
      a:hover {
        text-decoration: underline;
      }
      
      footer {
  background-color: #007bff;
  color: #fff;
  padding: 1rem;
  text-align: center;
  position: absolute;
  left: 0;
  bottom: -430px;
  width: 100%;
  text-align: center;
  padding: 20px 0;
  margin: 0;
  font-size: 1rem;
}
a:link {
      text-decoration: none;
      color: black;
}

a:visited {
      text-decoration: none;
      color: black;
}

a:hover {
    color: black;
      text-decoration: none;
}

a:active {
    color: black;
      text-decoration: none;
}

ul{
	display: flex;
	height: 30vh;
	margin: auto;
	justify-content: space-between;
	text-align: center;
}
li {
	padding: 1rem 2rem 1.15rem;
  text-transform: uppercase;
  cursor: pointer;
  color: black;
	min-width: 80px;
	margin: auto;
}

li:hover {
  background-image: url('https://scottyzen.sirv.com/Images/v/button.png');
  background-size: 100% 100%;
  color: #27262c;
  animation: spring 300ms ease-out;
  text-shadow: 0 -1px 0 #ef816c;
	font-weight: bold;
}
li:active {
  transform: translateY(4px);
}
    </style>
  </head>
  <body>
    <header>
      <h1>Условни оператори в PHP</h1>
    </header>
    
    <main>
      <section>
      <p>
    Условните оператори в PHP са мощен инструмент, който позволява на програмистите да изпълняват различни действия в 
    зависимост от условията. Сред основните условни оператори в PHP са if/else операторът, switch операторът и тернарният оператор.
    <br>
if/else операторът се използва, когато искаме да изпълним едно действие, ако дадено условие е изпълнено, 
и друго действие, ако условието не е изпълнено. switch операторът се използва, когато искаме да проверим 
стойността на една променлива и да изпълним различни действия, в зависимост от стойността. 
Тернарният оператор е кратък начин да се напише if/else оператор в един ред.
<br>
За да използвате условните оператори в PHP, е необходимо да знаете синтаксиса им и как да ги
 приложите в различни сценарии. Това включва разбиране на концепциите за оператори за сравнение, логически оператори и други.
 <br>
Най-добрият начин да научите как да използвате условните оператори в PHP е да практикувате и да
 създадете малки приложения, като например проверка на входните данни или обработка на формуляри
 . Това ще ви помогне да развиете уменията си в програмирането и да постигнете желаните резултати.
 <br>
 <h2>
 if-else оператор
 </h2>
 if (условие) {<br>
    // код, който да се изпълни ако условието е верно
    <br>
} else {<br>
    // код, който да се изпълни ако условието е невярно
    <br>
}
<br>
<h2>switch оператор</h2>
switch (израз) {<br>
    case стойност1: <br>
        // код, който да се изпълни ако изразът е равен на стойност1<br>
        break;<br>
    case стойност2:<br>
        // код, който да се изпълни ако изразът е равен на стойност2<br>
        break;<br>
    default:<br>
        // код, който да се изпълни ако изразът не е равен на нито една от стойностите<br>
        break;<br>
}
<br>
<h2>тернарен оператор</h2>
резултат = (условие) ? израз_ако_условието_е_верно : израз_ако_условието_е_неверно;
<br><br>
Тези условни оператори могат да бъдат комбинирани, за да се създадат по-сложни конструкции

</p>
      </section>
    </main>
    <nav>
    <ul>
            <li><a href="index.php">Начало</a></li>
			<li><a href="lessons.php">Уроци</a></li>
			<li><a href="lesson4.php">Следващ Урок</a></li>
			<li><a href="lesson2.php">Предишен Урок</a></li>
</ul>
    </nav>
    <footer>
    <p>&copy; 2023 Система за самообучение по PHP</p>
    </footer>
  </body>
</html>