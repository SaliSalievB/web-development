<!DOCTYPE html>
<html>
  <head>
    <title>Lesson Page</title>
    <style>
      body {
        font-family: Arial, sans-serif;
        background-color: #f0f0f0;
        margin: 0;
        padding: 0;
      }
      
      header {
        background-color: #007bff;
        color: #fff;
        padding: 20px;
        text-align: center;
      }
      
      h1 {
        
        margin: 0;
        font-size: 36px;
      }
      
      main {
        margin: 20px;
      }
      
      section {
        background-color: #fff;
        border: 1px solid #ccc;
        border-radius: 5px;
        padding: 10px;
        margin-bottom: 20px;
      }
      
      h2 {
        font-size: 24px;
        margin-top: 0;
      }
      
      p {
        font-size: 16px;
        line-height: 1.5;
      }
      
      ul {
        margin: 0;
        padding: 0;
        list-style: none;
      }
      
      li {
        margin-bottom: 10px;
      }
      
      a {
        color: #333;
        text-decoration: none;
        font-weight: bold;
      }
      
      a:hover {
        text-decoration: underline;
      }
      
      footer {
  background-color: #007bff;
  color: #fff;
  padding: 1rem;
  text-align: center;
  position: absolute;
  left: 0;
  bottom: -820px;
  width: 100%;
  text-align: center;
  padding: 20px 0;
  margin: 0;
  font-size: 1rem;
}
a:link {
      text-decoration: none;
      color: black;
}

a:visited {
      text-decoration: none;
      color: black;
}

a:hover {
    color: black;
      text-decoration: none;
}

a:active {
    color: black;
      text-decoration: none;
}

ul{
	display: flex;
	height: 30vh;
	margin: auto;
	justify-content: space-between;
	text-align: center;
}
li {
	padding: 1rem 2rem 1.15rem;
  text-transform: uppercase;
  cursor: pointer;
  color: black;
	min-width: 80px;
	margin: auto;
}

li:hover {
  background-image: url('https://scottyzen.sirv.com/Images/v/button.png');
  background-size: 100% 100%;
  color: #27262c;
  animation: spring 300ms ease-out;
  text-shadow: 0 -1px 0 #ef816c;
	font-weight: bold;
}
li:active {
  transform: translateY(4px);
}
    </style>
  </head>
  <body>
    <header>
      <h1>Обектно-ориентираното програмиране </h1>
    </header>
    
    <main>
      <section>
      <p>
      Обектно-ориентираното програмиране (ООП) е методология за програмиране, която позволява на програмистите 
       да създават програми, 
      които са по-лесни за поддръжка и променяне. <br>
      В PHP ООП е изключително мощен инструмент, който може да улесни и ускори процеса на разработка на уеб приложения.
       В следващите редове ще разгледаме някои от основните концепции на ООП в PHP.<br>

Класове и обекти<br>
Класовете са шаблони за обекти, които дефинират свойствата и методите на обектите, 
създадени от този клас. <br>
Обектите са конкретни инстанции на класа,
 които имат свои собствени стойности за свойствата и могат да изпълняват методите на класа.<br>
 В PHP класовете се дефинират с ключовата дума "class", а обектите се създават чрез оператора "new".<br>

Свойства и методи<br>
Свойствата на класа представляват данни, които принадлежат на обектите, създадени от класа. 
Те могат да бъдат публични, за да могат да бъдат достъпни отвън класа, или защитени/частни, 
за да могат да бъдат достъпни само от методите на класа. <br>
Методите на класа са функции, които могат да изпълняват действия със свойствата на класа или да връщат стойности.<br>

Конструктори и деструктори<br>
Конструкторите са специални методи на класа, които се изпълняват автоматично при създаване на обект от класа.
 Те са полезни за инициализация на свойствата на обекта. <br>Деструкторите са методи,
  които се изпълняват автоматично при унищожаване на обекта. Те са полезни за освобождаване на ресурси,
   като например затваряне на бази данни или файлове.<br>


Наследяване и полиморфизъм 
<br>
Наследяването е механизъм, който позволява на клас да наследява свойствата и методите на друг клас. <br>
Това позволява да се създават по-специализирани класове, които наследяват общите характеристики на по-генерален клас.<br>
 Полиморфизмът се отнася до възможността на обектите да се държат различно в зависимост от контекста, в който се използват.<br>
  Това означава, че обектите могат да изпълняват методите на родителския клас или да имат свои собствени методи.<br>

Пример за клас в PHP:<br>

class Person {<br>
  public $name;<br>
  private $age;<br>

  public function __construct($name, $age) {<br>
    $this->name = $name;<br>
    $this->age = $age;<br>
  }<br>

  public function getAge() {<br>
    return $this->age;<br>
  }<br>

  public function setAge($age) {<br>
    $this->age = $age;<br>
  }<br>
}<br>

$person = new Person("John", 30);<br>
echo $person->name; // извежда "John"<br>
echo $person->getAge(); // извежда 30<br>
$person->setAge(31);<br>
echo $person->getAge(); // извежда 31<br>
В този пример класът "Person" има две свойства: "name" (публично) и "age" (частно).<br>
 Също така има два метода: "getAge" и "setAge", за да се достъпва и променя "age" свойството. <br>
 Конструкторът приема име и възраст и инициализира свойствата на обекта. <br>
  С помощта на оператора "new" се създава инстанция на класа и се извеждат неговите свойства и методи.<br>

ООП в PHP е мощен инструмент, който може да улесни разработката на уеб приложения. <br>
Правилната употреба на класове, обекти, свойства, методи, конструктори, деструктори, наследяване и полиморфизъм 
може да доведе до по-лесен за поддръжка и разширяем код.
    </p>
      </section>
    </main>
    <nav>
    <ul>
            <li><a href="index.php">Начало</a></li>
			<li><a href="lessons.php">Уроци</a></li>
			<li><a href="lesson12.php">Упражнение 2</a></li>
			<li><a href="lesson10.php">Предишен Урок</a></li>
</ul>
    </nav>
    <footer>
    <p>&copy; 2023 Система за самообучение по PHP</p>
    </footer>
  </body>
</html> 