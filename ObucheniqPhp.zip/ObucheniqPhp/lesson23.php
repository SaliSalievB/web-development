<!DOCTYPE html>
<html>
  <head>
    <title>Lesson Page</title>
    <style>
      body {
        font-family: Arial, sans-serif;
        background-color: #f0f0f0;
        margin: 0;
        padding: 0;
      }
      
      header {
        background-color: #007bff;
        color: #fff;
        padding: 20px;
        text-align: center;
      }
      
      h1 {
        
        margin: 0;
        font-size: 36px;
      }
      
      main {
        margin: 20px;
      }
      
      section {
        background-color: #fff;
        border: 1px solid #ccc;
        border-radius: 5px;
        padding: 10px;
        margin-bottom: 20px;
      }
      
      h2 {
        font-size: 24px;
        margin-top: 0;
      }
      
      p {
        font-size: 16px;
        line-height: 1.5;
      }
      
      ul {
        margin: 0;
        padding: 0;
        list-style: none;
      }
      
      li {
        margin-bottom: 10px;
      }
      
      a {
        color: #333;
        text-decoration: none;
        font-weight: bold;
      }
      
      a:hover {
        text-decoration: underline;
      }
      
      footer {
  background-color: #007bff;
  color: #fff;
  padding: 1rem;
  text-align: center;
  position: absolute;
  left: 0;
  bottom: -300px;
  width: 100%;
  text-align: center;
  padding: 20px 0;
  margin: 0;
  font-size: 1rem;
}
a:link {
      text-decoration: none;
      color: black;
}

a:visited {
      text-decoration: none;
      color: black;
}

a:hover {
    color: black;
      text-decoration: none;
}

a:active {
    color: black;
      text-decoration: none;
}

ul{
	display: flex;
	height: 30vh;
	margin: auto;
	justify-content: space-between;
	text-align: center;
}
li {
	padding: 1rem 2rem 1.15rem;
  text-transform: uppercase;
  cursor: pointer;
  color: black;
	min-width: 80px;
	margin: auto;
}

li:hover {
  background-image: url('https://scottyzen.sirv.com/Images/v/button.png');
  background-size: 100% 100%;
  color: #27262c;
  animation: spring 300ms ease-out;
  text-shadow: 0 -1px 0 #ef816c;
	font-weight: bold;
}
li:active {
  transform: translateY(4px);
}
    </style>
  </head>
  <body>
    <header>
      <h1>PHP Frameworks и CMS.</h1>
    </header>
    
    <main>
      <section>
      <p>PHP Frameworks и CMS (Content Management Systems) са инструменти за ускоряване и улесняване на процеса на разработка на
         уеб приложения и уеб сайтове,
         които използват PHP езика за програмиране. <br>

Ето някои от най-известните PHP фреймуърки:<br>

Laravel -<br>
 Laravel е един от най-популярните PHP фреймуърки. <br>
Той предоставя много готови функции за работа с бази данни, сесии, рутинг и други,
 което го прави изключително ефективен за разработка на малки и големи проекти.<br>

Symfony - <br>
Symfony е друг известен PHP фреймуърк, който е подходящ за по-големи проекти. <br>
Той предоставя много гъвкавост и контрол върху приложението и също така предоставя готови компоненти за различни задачи,
 като работа с форми, тестове и др.<br>

CodeIgniter - <br>
CodeIgniter е лек PHP фреймуърк, който е подходящ за по-малки проекти. <br>
Той предоставя много готови функции за работа с бази данни, форми, сесии и други, 
което го прави изключително ефективен за бърза разработка на малки проекти.<br>

Ето и някои от най-известните PHP CMS:<br>

WordPress -<br>
 WordPress е известен като един от най-популярните CMS, който е подходящ за създаване на блогове,
 уеб сайтове и онлайн магазини. Той е лесен за употреба и разширяване, като предоставя голям брой плъгини и теми.<br>

Drupal - <br>
Drupal е CMS, който е подходящ за по-големи и сложни уеб проекти. <br>
Той предоставя много гъвкавост и контрол върху приложението, като предоставя готови модули за различни задачи.<br>

Joomla - <br>
 Joomla е CMS, който е подходящ за създаване на блогове, уеб сайтове и онлайн магазини. <br>
 Той е лесен за употреба и разширяване, като предоставя голям брой модули и теми.<br>
    </p>
      </section>
    </main>
    <nav>
    <ul>
            <li><a href="index.php">Начало</a></li>
			<li><a href="lessons.php">Уроци</a></li>
			<li><a href="lesson24.php">Упражнение 4 и 5 </a></li>
			<li><a href="lesson22.php">Предишен Урок</a></li>
</ul>
    </nav>
    <footer>
    <p>&copy; 2023 Система за самообучение по PHP</p>
    </footer>
  </body>
</html> 