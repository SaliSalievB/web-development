<!DOCTYPE html>
<html>
  <head>
    <title>Lesson Page</title>
    <style>
      body {
        font-family: Arial, sans-serif;
        background-color: #f0f0f0;
        margin: 0;
        padding: 0;
      }
      
      header {
        background-color: #007bff;
        color: #fff;
        padding: 20px;
        text-align: center;
      }
      
      h1 {
        
        margin: 0;
        font-size: 36px;
      }
      
      main {
        margin: 20px;
      }
      
      section {
        background-color: #fff;
        border: 1px solid #ccc;
        border-radius: 5px;
        padding: 10px;
        margin-bottom: 20px;
      }
      
      h2 {
        font-size: 24px;
        margin-top: 0;
      }
      
      p {
        font-size: 16px;
        line-height: 1.5;
      }
      
      ul {
        margin: 0;
        padding: 0;
        list-style: none;
      }
      
      li {
        margin-bottom: 10px;
      }
      
      a {
        color: #333;
        text-decoration: none;
        font-weight: bold;
      }
      
      a:hover {
        text-decoration: underline;
      }
      
      footer {
  background-color: #007bff;
  color: #fff;
  padding: 1rem;
  text-align: center;
  position: absolute;
  left: 0;
  bottom: -350px;
  width: 100%;
  text-align: center;
  padding: 20px 0;
  margin: 0;
  font-size: 1rem;
}
a:link {
      text-decoration: none;
      color: black;
}

a:visited {
      text-decoration: none;
      color: black;
}

a:hover {
    color: black;
      text-decoration: none;
}

a:active {
    color: black;
      text-decoration: none;
}

ul{
	display: flex;
	height: 30vh;
	margin: auto;
	justify-content: space-between;
	text-align: center;
}
li {
	padding: 1rem 2rem 1.15rem;
  text-transform: uppercase;
  cursor: pointer;
  color: black;
	min-width: 80px;
	margin: auto;
}

li:hover {
  background-image: url('https://scottyzen.sirv.com/Images/v/button.png');
  background-size: 100% 100%;
  color: #27262c;
  animation: spring 300ms ease-out;
  text-shadow: 0 -1px 0 #ef816c;
	font-weight: bold;
}
li:active {
  transform: translateY(4px);
}
    </style>
  </head>
  <body>
    <header>
      <h1>Деклариране на променливи в PHP</h1>
    </header>
    
    <main>
      <section>
        <p>Деклариране на променливи в PHP
Декларирането на променливи в PHP се извършва като изпишем знака $ и 
непосредстевно след него името с което искаме да идентифицираме променливата.
            </p>
            <br>
            <p>
            <br>
$txt = "Hello world!";
<br>
$x = 5;
<br>
$y = 10.5;
<br>

След изпълнението на горния пример, $txt ще има стойност „Hello world!“, $x ще има стойност 5,
 а $y ще има стойност от 10.5. За разлика от другите програмни езици, при PHP няма определена 
 команда за създаване на променлива. Те се създават при първото им инициализиране.
Също така, PHP е безтипов език.
<br>
Това означава, че по един и същи начин се създава променлива
 от тип string, integer или boolean. Тоест просто присвояваме някаква стойност към името на променливата.
  PHP автоматично превръща променливата в съответния тип, в зависимост от типът на стойността, която е зададена.
При други езици за програмиране като например JavaScript, C, C++ или Java трябва изрично 
да се декларира типът променлива преди да започне да се използва.
Най-важното, което трябва да имате предвид при създаването на променливи е в следната таблица:
<br>
Променливата се обявява със $ знак последван от името и(без интервал помежду им)
Името трябва да започва със буква или _(долна черта)
Името на променливата не може да започва с цифра
Може да съдържа само букви, числа и долни черти
$age и $AGE са две различни променливи, тъй като PHP е case-sensitive език.

<br>

<h2 class="lesson-title">Типовете данни в PHP</h2>
<p>
Променливите могат да съхраняват данни от различни типове и различните типове данни могат да правят различни неща. PHP поддържа следните типове данни:

String
<br>
Integer
<br>
Float
<br>
Boolean
<br>
Array
<br>
Object
<br>
NULL
<br>
Resource
</p>
            </p>
      </section>
    </main>
    <nav>
    <ul>
            <li><a href="index.php">Начало</a></li>
			<li><a href="lessons.php">Уроци</a></li>
			<li><a href="lesson3.php">Следващ Урок</a></li>
			<li><a href="lesson1.php">Предишен Урок</a></li>
</ul>
    </nav>
    <footer>
    <p>&copy; 2023 Система за самообучение по PHP</p>
    </footer>
  </body>
</html>