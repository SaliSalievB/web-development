<!DOCTYPE html>
<html>
  <head>
    <title>Lesson Page</title>
    <style>
      body {
        font-family: Arial, sans-serif;
        background-color: #f0f0f0;
        margin: 0;
        padding: 0;
      }
      
      header {
        background-color: #007bff;
        color: #fff;
        padding: 20px;
        text-align: center;
      }
      
      h1 {
        
        margin: 0;
        font-size: 36px;
      }
      
      main {
        margin: 20px;
      }
      
      section {
        background-color: #fff;
        border: 1px solid #ccc;
        border-radius: 5px;
        padding: 10px;
        margin-bottom: 20px;
      }
      
      h2 {
        font-size: 24px;
        margin-top: 0;
      }
      
      p {
        font-size: 16px;
        line-height: 1.5;
      }
      
      ul {
        margin: 0;
        padding: 0;
        list-style: none;
      }
      
      li {
        margin-bottom: 10px;
      }
      
      a {
        color: #333;
        text-decoration: none;
        font-weight: bold;
      }
      
      a:hover {
        text-decoration: underline;
      }
      
      footer {
  background-color: #007bff;
  color: #fff;
  padding: 1rem;
  text-align: center;
  position: absolute;
  left: 0;
  bottom: -420px;
  width: 100%;
  text-align: center;
  padding: 20px 0;
  margin: 0;
  font-size: 1rem;
}
a:link {
      text-decoration: none;
      color: black;
}

a:visited {
      text-decoration: none;
      color: black;
}

a:hover {
    color: black;
      text-decoration: none;
}

a:active {
    color: black;
      text-decoration: none;
}

ul{
	display: flex;
	height: 30vh;
	margin: auto;
	justify-content: space-between;
	text-align: center;
}
li {
	padding: 1rem 2rem 1.15rem;
  text-transform: uppercase;
  cursor: pointer;
  color: black;
	min-width: 80px;
	margin: auto;
}

li:hover {
  background-image: url('https://scottyzen.sirv.com/Images/v/button.png');
  background-size: 100% 100%;
  color: #27262c;
  animation: spring 300ms ease-out;
  text-shadow: 0 -1px 0 #ef816c;
	font-weight: bold;
}
li:active {
  transform: translateY(4px);
}
    </style>
  </head>
  <body>
    <header>
      <h1>Създаване на функция в PHP</h1>
    </header>
    
    <main>
      <section>
      <p>
      За да създадете функция в PHP, трябва да следвате тези стъпки: <br>
      Използвайте ключовата дума "function", за да зададете, че ще създадете функция. Синтаксисът е:<br>
      function function_name(){<br>
    //тяло на функцията<br>
}<br>
Дайте име на функцията, което трябва да бъде описателно и да описва дейността на функцията.<br>
 Името на функцията може да съдържа букви, цифри и долно подчертаване, но не може да започва с цифра. Например:<br>
 function calculate_sum(){<br>
    //тяло на функцията<br>
}<br>
Дефинирайте параметрите на функцията, ако има такива. Параметрите се<br>
 задават в скобите след името на функцията и могат да бъдат използвани в тялото на функцията за да подадат стойности. Например:<br>
 function calculate_sum($num1, $num2){<br>
    //тяло на функцията<br>
}<br>
Напишете кода на функцията, като използвате оператори и изрази, както и използвайки параметрите, ако има такива. Например:<br>
function calculate_sum($num1, $num2){<br>
    $sum = $num1 + $num2;<br>
    return $sum;<br>
}<br>
Използвайте ключовата дума "return" за да върнете резултат от функцията. <br>
Когато се изпълни функцията, тя ще върне този резултат на мястото, където е била извикана. Например:<br>
function calculate_sum($num1, $num2){<br>
    $sum = $num1 + $num2;<br>
    return $sum;<br>
}<br>

$result = calculate_sum(5, 10);<br>
echo $result; //ще изпише 15<br>

Това е основата за създаване на функция в PHP. Можете да използвате функции, за да обедините повтарящ се код, <br>
за да улесните четимостта на кода и за да направите кода си по-модулен и лесен за разширяване.<br>
    </p>
      </section>
    </main>
    <nav>
    <ul>
            <li><a href="index.php">Начало</a></li>
			<li><a href="lessons.php">Уроци</a></li>
			<li><a href="lesson8.php">Следващ Урок</a></li>
			<li><a href="lesson5.php">Предишен Урок</a></li>
</ul>
    </nav>
    <footer>
    <p>&copy; 2023 Система за самообучение по PHP</p>
    </footer>
  </body>
</html> 